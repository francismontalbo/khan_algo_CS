# Workflow Algorithm Research Guide

A downloadable study app for a two-semester BSCS algorithm thesis. **Students open it locally in a browser. GitHub is used only to store and share the files.**

## Open the app

1. Download the **complete project**. On the repository page, select **Code → Download ZIP**, or use the ZIP provided by your instructor.
2. **Extract the entire ZIP**. On Windows, select **Extract All**; on macOS, double-click the ZIP.
3. Open the extracted folder and double-click **`index.html`**. If it opens in an editor, use **Open with** and choose a web browser.

**`index.html` is only the starting page—not the complete app.** Keep all supplied files and folders together. Do not open the file inside the ZIP or expect GitHub's file viewer to run it.

Normal use requires no installation, terminal commands, Python, Node.js, server, database, or app account. A laptop or desktop browser is the intended environment.

## Start studying

Choose **Start with Kahn** for the foundations, **Simulate** to follow an algorithm, or **Compare methods** to inspect differences. The guide includes the research tree, proofs beside code, computing applications, terminology tooltips, learning resources, and research questions.

| Entry | Purpose |
| --- | --- |
| `index.html` | Landing page. Open this first. |
| `Workflow_Research_Guide.html` | Integrated app and method comparisons. |
| `Algorithm_Lessons.html` | Algorithm foundations. |
| `Algorithm_Simulations.html` | Interactive simulations. |
| `Algorithm_Applications.html` | Computing applications and supporting evidence. |
| `data`, `code`, `simulations`, `applications`, and `release` | Source records, app files, and research code. Keep these folders. |
| `reference/Original_Research_Package.zip` | Earlier research materials. No need to extract this archive to use the app. |

The remaining reference pages, source files, and optional tests are also included.

## Save your notes

Notes use the current browser's storage where available. They do **not** synchronize to GitHub or an instructor database. Export them regularly using the guide's save or export controls, especially before switching browsers, replacing the app folder, or changing devices. Import the saved file to restore your work.

The stored guide and simulations work offline. External papers, source websites, and videos need internet. Local-file storage and playback restrictions can vary between browsers.

## Add the files to your repository

Extract the application ZIP and copy the **contents** of `workflow-research-guide` into your repository, keeping `README.md` and `index.html` at the top level. Preserve existing repository files and your `.git` folder; review changes before committing and pushing.

Share the repository address with students. They download and open the app using the steps above. **No website publishing or hosting configuration is involved.**

This README replaces `DEPLOY.md`. Remove that old file from your repository if it remains. Upload the complete extracted project, not just `index.html`.

## Troubleshooting

A missing page usually means the ZIP was not fully extracted or files were moved. Extract the complete package again and retain its names and structure. If HTML opens as text, open the extracted file with a browser. For unavailable videos, use their official-page links. For missing notes, import your saved export.

## Maintenance and research scope

Students do not need developer tools. Maintainers can use [TESTING.md](TESTING.md) for optional checks and asset synchronization. [Verification.html](Verification.html) records the earlier checks and their limits; direct local-file navigation could not be tested in the preparation environment.

**Research snapshot: 15 October 2026. Instructions updated: 19 October 2026.** This is a documentation update, not a new literature review. The guide supports proposal development but does not certify novelty. Teaching simulations are not real Montage performance benchmarks.

Preserve [source attribution](code/SOURCE_ATTRIBUTION.md), the included [Apache 2.0 license](code/APACHE-2.0.txt), and [privacy and usage notes](NOTICE.md). External material remains with its publishers.

Download steps follow [GitHub's source archive documentation](https://docs.github.com/en/repositories/working-with-files/using-files/downloading-source-code-archives).
