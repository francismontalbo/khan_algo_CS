# Optional checks for maintainers

Students need only a browser. The following commands are for the repository owner.

## Package and link checks — Python standard library

```bash
python3 tools/check_site.py
python3 tools/sync_assets.py --check
```

These check the HTML pages, local destinations, portable relative paths, embedded source consistency, and required source/license files. They do not validate every literature claim or external URL.

## Algorithm checks

Use Python 3.10 or newer and Node.js. The shipped dependency pin records the tested NetworkX version; it is not a claim about the latest library release.

```bash
python3 -m venv .venv
# macOS or Linux
source .venv/bin/activate
# Windows PowerShell alternative: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-dev.txt
python verify.py
```

The independent Python proof suite requires only the standard library:

```bash
python3 code/run_checks.py --cases 5000
```

Tests write fresh results below `tests/`. They use finite synthetic cases, including application-shaped teaching inputs. Passing them is not a proof of historical novelty, measured production benefit, or general correctness for assumptions outside the declared models.

## Browser smoke check

The optional script uses Playwright and Chromium. These are not requirements for opening the app.

```bash
python -m pip install playwright
python -m playwright install chromium
python tools/check_browser.py
```

With a system Chromium, set `CHROMIUM_PATH` to its executable. This maintainer-only test may start a temporary local server to exercise browser navigation. If the environment blocks that route, it falls back to loading unchanged HTML contents and records the limitation. Students do not need a server or these test tools. HTTP checks do not by themselves verify local-file behavior.

## Research freshness

Packaging validation is dated 19 October 2026. The retained literature snapshot and its coverage limits are dated 15 October 2026. Recheck the closest papers and implementation versions before a student makes a novelty claim.
