# Workflow Algorithm Research Guide

**Final edition — 15 October 2026**

Open **index.html** in a recent desktop browser. The home page links directly to lessons, simulations, comparisons and research questions. **Workflow_Research_Guide.html** remains the complete guide. The page contains the research records, comparisons, lessons and simulations; it does not need a server or an account. External articles and videos require internet. The older filename, `Workflow_Visual_Comparison.html`, is kept as an identical compatibility copy.

## A useful reading order

1. **Algorithms** explains the foundations. **Simulate** shows the procedure, equations, code and output together.
2. **Compare** aligns methods on the same criteria. The first comparison is Kahn and priority selection. Use the presets for later methods, or choose two or three yourself.
3. **View source** shows the evidence and its limits. **Real use** connects a method with actual computing applications. **Research tree** shows the relationships.
4. **More → Research questions** and **Your proposal notes** help you frame your own contribution. Questions are prompts, not supplied solutions or cleared novelty claims.

Dotted terms open definitions. Closing a definition, application or lesson returns to the previous view. Use **Save comparison** for a portable HTML comparison. Use **More → Save comparison notes** for editable comparison selections and draft fields; use the separate notes export for the long-form proposal notes. Browser storage is not a backup.

## What is included

- 58 selectable methods, source versions and teaching examples, including 36 evidence records (35 external and one local validation record).
- The retained historical lineage and a connected research tree.
- Side-by-side process, mathematical and code comparisons, source attribution, strengths, limitations and research prompts.
- 23 runnable teaching simulations, 33 small input scenarios, 23 real-application profiles and 31 application references.
- 10 algorithm lessons, 63 learning resources (27 videos and 36 written resources), and 249 terminology entries.
- Python and JavaScript implementations, finite correctness tests, benchmark planning and reproducibility records.

Related source versions are not independent studies. Application examples are synthetic adaptations unless explicitly marked otherwise.

## Home page

`index.html` is the starting page. The guide’s brand and **More → Home** return to it. All companion pages also have a **Home** link. The page has no external dependencies, account requirement, tracking or autoplay. When sharing, keep the whole extracted folder together.

## Direct entry pages

- `Algorithm_Lessons.html`
- `Algorithm_Simulations.html`
- `Algorithm_Applications.html`
- `Workflow_Learning_Resources.html`
- `Workflow_Terms_and_Nomenclature.html`
- `Verification.html`

Use the main guide for the integrated experience. Direct-entry pages are optional.

## Reproduce the checks

For the complete algorithm suite, use Python 3.10 or newer, Node.js and NetworkX:

```text
python -m pip install networkx
python verify.py
```

The browser guide itself needs none of those installations. Tests create results under `tests/final`. The Python proof suite can also run by itself with the standard library:

```text
python code/run_checks.py --cases 5000
```

Browser checks require Playwright and a Chromium browser. See `tests/final/check_release_ui.py`. `release/build_final.py` requires BeautifulSoup and rebuilds the polished pages from the preserved previous edition, with the current metadata correction. Earlier build scripts and tests are retained for provenance; use the final entry points rather than replaying every historical patch.

## Boundaries

This is a curated research guide, not an exhaustive systematic review or a certificate of novelty. Full methods for abstract-only records still need to be read. The supplied tests are finite synthetic checks, not measured Montage speedups or proofs of published implementation performance. The selected real Montage files have not been executed as benchmarks here.

The final source check corrected LATTICE version 3 and retained its previous DAN-Scheduler title. Its latest abstract and revision metadata were checked; the full revised implementation was not reproduced. Other access limitations remain with their records.

Videos were not audited end to end, and external playback was not confirmed. Browser testing used Chromium with desktop and emulated narrow views. File-origin navigation was blocked in the verification environment; local HTML contents were loaded for interaction tests. Safari, Firefox and physical devices were not tested.

## Files and provenance

`data`, `applications`, `simulations` and `code` contain the editable records and implementations. `release` describes this edition and includes its final presentation layer. `tests/final` contains the new verification results. `archive` retains earlier content and notes for traceability, not as recommended starting pages.

Original third-party code attribution and the Apache license are in `code/SOURCE_ATTRIBUTION.md` and `code/APACHE-2.0.txt`. Source links do not transfer rights to linked papers or videos. `SHA256SUMS.json` records the delivered file hashes.
