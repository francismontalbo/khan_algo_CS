"""Build additive, offline application profiles into the retained reader pages."""
from pathlib import Path
import re,json,hashlib
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parents[1]
store=ROOT/'archive'/'Before_Applications';store.mkdir(exist_ok=True)
pages=['Workflow_Visual_Comparison.html','Algorithm_Simulations.html','Algorithm_Lessons.html','Workflow_Learning_Resources.html']
for fn in pages:
 if not (store/fn).exists():(store/fn).write_bytes((ROOT/fn).read_bytes())
enginehash=hashlib.sha256((ROOT/'simulations/engine.js').read_bytes()).hexdigest()
simdata=(ROOT/'simulations/data.json').read_text().replace('</','<\\/')
appdata=(ROOT/'applications/data.json').read_text().replace('</','<\\/')
style=(ROOT/'applications/applications.css').read_text();js=(ROOT/'applications/applications.js').read_text()
simjs=(ROOT/'simulations/ui.js').read_text()
simjs=simjs.replace("if(!dialog.open)return;if(e.key==='Escape')", "if(!dialog.open||document.querySelector('#app-dialog[open]'))return;if(e.key==='Escape')")
# Long meaningful task names remain readable inside the graph nodes.
old="'<text x=\"'+x+'\" y=\"'+(y+1)+'\" style=\"font-size:'+(v.length>6?10:14)+'px\">'+esc(v)+'</text>'"
# The original renderer builds the text inside a longer string; replace its small expression only.
needle="<text x=\"'+x+'\" y=\"'+(y+1)+'\" style=\"font-size:'+(v.length>6?10:14)+'px\">'+esc(v)+'</text>"
replace="<text x=\"'+x+'\" y=\"'+(y+1)+'\" style=\"font-size:'+(v.length>6?10:14)+'px\">'+(v.length>6&&/[a-z][A-Z]/.test(v)?v.replace(/([a-z])([A-Z])/g,'$1 $2').split(' ').map((part,j)=>'<tspan x=\"'+x+'\" dy=\"'+(j===0?-5:11)+'\">'+esc(part)+'</tspan>').join(''):esc(v))+'</text>"
if needle in simjs:simjs=simjs.replace(needle,replace)
(ROOT/'simulations/ui.js').write_text(simjs)
addon='\n<style id="applications-style">'+style+'</style>\n<script id="applications-data" type="application/json">'+appdata+'</script>\n<script id="applications-ui">'+js+'</script>\n'
def replace_script(t,id,new):
 pattern=r'(<script\b[^>]*\bid="'+re.escape(id)+r'"[^>]*>).*?(</script>)'
 t,n=re.subn(pattern,lambda m:m[1]+new+m[2],t,flags=re.S)
 assert n==1,(id,n)
 return t
for fn in pages:
 t=(store/fn).read_text()
 t=replace_script(t,'simulation-data',simdata)
 t=replace_script(t,'simulation-ui',simjs)
 pos=t.rfind('</body>');assert pos>=0; t=t[:pos]+addon+t[pos:]
 (ROOT/fn).write_text(t)
# A short standalone entry uses the identical simulator and application module.
t=(ROOT/'Algorithm_Simulations.html').read_text()
t=t.replace('data-sim-standalone="true"','data-app-standalone="true"')
t=re.sub(r'<title>.*?</title>','<title>Real Computing Applications | Algorithm Guide</title>',t,flags=re.S)
t=re.sub(r'<main\b[^>]*>.*?</main>', '<main><p class="app-kicker">Workflow algorithm research guide</p><h1>Algorithms solving computing problems</h1><p>See the real software or research setting, inspect the evidence, then run a small named example.</p><p><button type="button" data-app-open="fifo" class="app-primary">Explore real applications</button></p><p><a href="Workflow_Visual_Comparison.html">Return to the full comparison guide</a></p><p>23 algorithm profiles. Software use, research evaluations and local teaching extensions are clearly separated.</p></main>',t,count=1,flags=re.S)
(ROOT/'Algorithm_Applications.html').write_text(t)
meta={'updated':'2026-10-15','original_engine_sha256':enginehash,'current_engine_sha256':hashlib.sha256((ROOT/'simulations/engine.js').read_bytes()).hexdigest(),'pages':pages+['Algorithm_Applications.html'],'original_research_records_unchanged':hashlib.sha256((ROOT/'data/Explorer_Data.json').read_bytes()).hexdigest()}
(ROOT/'tests/applications/Build_Manifest.json').write_text(json.dumps(meta,indent=2))
print('Built',len(pages)+1,'pages; core simulation engine unchanged:',meta['original_engine_sha256']==meta['current_engine_sha256'])
