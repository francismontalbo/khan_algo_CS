# Literature review audit

**Status: Share as a research guide with caveats. Not yet a complete systematic review or evidence of a novel tested algorithm.**

Cutoff: 15 October 2026. Events after this date and the remainder of 2026 are outside the audit.

## What was checked

The full local page structure, comparison data, lineage data, glossary and learning links were inventoried. The interface tests cover all definitions, method-learning views and resource detail pages, plus the comparison, source preview, tree, exports and narrow-layout paths. Repetitive paths share code; every possible combination was not independently inspected.

Primary-source review concentrated on claims that change the thesis decision: XLA priority updates and its September 2026 representation change, Singh et al.’s cleanup reduction, memory-model compatibility, actual comparative findings, and newer scheduling research. Every source record carries an audit level. Sources with only abstracts were not relabeled as full-text verified.

## Material repairs

- Corrected attribution of dense indexing to the later XLA revision rather than its predecessor.
- Added omitted metadata-management work (Horizons), the shared-output memory-model boundary (Jin et al.), a joint scheduling result, and July and October 2026 preprints. Their different objectives are explicit.
- Replaced bibliographic placeholders with primary metadata where available; online versus issue dates remain separate. Unresolved final dates are still flagged.
- Added the actual update queries, specific borderline inclusion decisions, evidence-family labels, and reasons for excluding unlike methods from a numerical comparison. The original search history cannot be reconstructed in full.
- Corrected a hardcoded date in the local test runner and repaired invalid paths to test results. Algorithm code was otherwise not changed.
- Repaired the older source-export payload so it now saves the same 36 records shown on the audited page.

## What prevents a no-cherry-picking claim

This is a single-assessor retrospective audit with ranked search results, incomplete historical retrieval records and limited full-text access. It cannot establish complete retrieval or zero selection bias. The added log makes future decisions inspectable; it does not retroactively make the earlier collection systematic.

Before the final thesis review, two students should independently screen borderline records; agree explicit criteria; search backwards and forwards from the closest studies; retain unfavorable and null results; group repeated versions; and record inaccessible studies rather than treating them as absent. Search again for the students’ precise eventual mechanism.

No comparison should combine peak memory, cache-hit rate, total workload time and scheduler construction time as if they were the same metric. A compiler buffer is not automatically a workflow file. Different shared-output and edge-output models can yield different tractability results.

## 2026 coverage

The existing average-memory and predicted strong-component records remain with their access limits. The XLA scheduler’s latest inspected file change by the cutoff is 25 September 2026. DAN-Scheduler (19 July) and MoSAIC (10 October) are included as preprints, not certified peer-reviewed results. Other recent, differently scoped leads remain in the screening log. This is current targeted coverage, not an exhaustive census of 2026 publications.

## What the guide can support

It can help students define one precise computational problem, identify close prior art, avoid invented novelty, formulate a falsifiable question, establish a correctness contract, and plan a CPU-only benchmark. It cannot select an entirely new algorithm by elimination from an incomplete source collection.

The proposal still needs its own exact rule and local evidence that the targeted cost matters. Keep total order-construction time as the primary metric and counter-update work as the explanation. Include preparation costs, competent simple controls, all selected workflow cases and unsuccessful runs. Do not turn repeated timing runs into additional independent workflows.

## Remaining substantive gaps

1. Several close and contextual records remain abstract-only. Complete their full-method extraction before using detailed claims.
2. Full original Montage JSON inputs and content hashes were not obtained here; no real Montage timing improvement is demonstrated.
3. The students’ eventual modification and an independent novelty check remain open.
4. Videos were not watched end to end, live playback was not verified and only a sample of four official learning pages was reopened in this audit.
5. Browser checks used Chromium injected HTML and emulated touch. File-origin behavior and Safari were not independently tested.
6. PDF screenshot rendering failed for selected manuscripts. Textual evidence was inspected; no new chart values were extracted.

## Reproduction and files

- `data/Audit_Search_Log.json`: actual queries and their limits.
- `data/Audit_Screening_Log.csv`: retained records and explicit borderline leads.
- `data/Audit_Findings.json`: repairs, limitations and learning-page sample.
- `data/Explorer_Data.json`: per-source audit levels and family labels.
- `results/checks.json`: current synthetic test results.
- `tests/current_audit`: interface logs and new audit checks.
- `archive/Before_15_October_Audit.html`: unchanged audit input.

Run `python code/run_checks.py --cases 5000` to reproduce the finite correctness suite. The test graph generator intentionally creates repeated consumer patterns; its outputs are not an unbiased workload-performance sample.

## Methodological source

Wohlin, Mendes, Felizardo and Kalinowski, “Guidelines for the Search Strategy to Update Systematic Literature Reviews in Software Engineering,” author preprint arXiv:2006.05542. The primary abstract supports citation-based update searching and highlights more than one assessor for selection. It does not certify this audit’s completeness.

## Final local checks

The final page rendered all 58 selectable records through the shared full-specification and source-preview paths. The new references, tree locations, source filtering, saved comparison caveats and source export passed. The page has no duplicate IDs or broken literal internal anchors. The final desktop and narrow-screen checks reported no JavaScript errors. Screenshot evidence is retained under tests/current_audit. These results do not imply that all external links, every browser or every scientific claim were independently validated.
