# Workflow research guide

Open **Workflow_Visual_Comparison.html** in a browser.

## Start here

- **Compare methods** goes straight to the comparison controls.
- **Learn the algorithms** opens the algorithm lessons.
- The top menu stays visible: **Compare**, **Algorithms**, and **Research tree**.
- **Terms & symbols** opens the glossary. **More** contains the sources, tutorials, research questions, experiment plan, notes, review status, and printing.

Within a comparison, use **Change method**, **View source**, or **Learn this method**. Use **Back to comparison** to close a lesson or definition. Export notes to keep a portable copy.

## Companion pages

Algorithm_Lessons.html, Workflow_Learning_Resources.html, and Workflow_Terms_and_Nomenclature.html remain available separately. Their menus and controls use the same button styles.

## This revision

Larger primary actions, consistent outlined secondary buttons, visible selected states, keyboard focus indicators, immediate section navigation, and a compact reference menu. The interface works at desktop and narrow widths while the comparison retains horizontal columns.

Research records, mathematical material, algorithms, video metadata, and original evidence limits were retained. This was not a new literature review or performance experiment.

## Verification

The supplied HTML was rendered in Chromium at 1440, 768, 390, and 320 pixel viewport widths. Checks exercised menus, method selection, comparison views, glossary details, lessons, return controls, exports, and keyboard navigation. The tested mobile pages had no whole-document horizontal overflow; the comparison table deliberately scrolls horizontally.

Research JSON blocks match the previous artifact byte for byte. All retained Python files match the supplied package. JavaScript syntax checks passed. Test records are in tests/UI_*.json; screenshots are in assets/ui_update.

The browser checks used locally supplied DOM content. External video playback, network links, file-origin storage, Safari, and other browser engines were not retested. Existing notes import and export remain available.

## Editable UI files

The delivered HTML is self-contained. code/ui-polish.css and code/ui-polish.js contain the new interface styling and navigation behavior. Preserve the research data scripts when changing the interface.
