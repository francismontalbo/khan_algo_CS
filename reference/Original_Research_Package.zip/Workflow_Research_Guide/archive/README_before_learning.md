# Workflow visual comparison with terms and symbols

Open `Workflow_Visual_Comparison.html`. The comparison is self-contained. No server or installation is needed. Definitions work offline; original external references require an internet connection.

## Quick reference

- **Terms & symbols** opens searchable abbreviation, nomenclature, concept and code-name tables.
- Hover or keyboard-focus a dotted term for a short definition. Select the term, or the popup's **Read explanation**, for its meaning, example, cautions and sources.
- **Back to reading** or Escape returns to the same comparison and scroll position.
- Terms inside existing buttons and source links do not replace those controls. Hover for the definition and use its separate explanation action. On touch screens, use the linked term in the selected method's heading or the reference tables.
- **Symbols** beside a mathematical statement opens the nomenclature table. Single letters are not automatically interpreted in ordinary prose.
- **Save this view** retains the reference in the exported comparison. **Save reference tables** exports a standalone reference document.
- `Workflow_Terms_and_Nomenclature.html` is the already exported reference-table document.

## Comparison features retained

Process, Code and All specifications views; two or three aligned methods; highlighted differences; related sources; method connection tree; research questions; proof notes; source previews; editable proposal notes; notes import and export.

The algorithm examples, historical source records, benchmark manifest and comparison-note format are unchanged. No new performance result or novelty claim is added.

## Contents

`data/Terminology.json` contains the added reference records. `code/reference.js`, `code/reference.css` and `code/reference-shell.html` implement the reference interface. The original algorithm code remains in `code`. Earlier records and proof materials remain in `archive`.

Edit the JS, CSS or JSON files and run `python code/update_html.py` to update embedded assets. Shell markup is initially installed in the HTML; editing its separate template alone does not replace the installed shell.

## Validation

`tests/check_visual_ui.py` exercises the original comparison actions. `tests/check_reference_ui.py` exercises search, all 248 definitions, related links, code-text preservation, source dialogs, exports and mobile touch behavior. Their JSON results document the checks actually completed. Definitions include scope warnings rather than assigning one meaning to a symbol across unrelated papers.

Tested in Chromium with injected standalone HTML and emulated touch. File-origin browser storage and Safari were not independently tested. Portable note export remains the recommended way to preserve notes across files or devices.
