# Workflow comparison with algorithm lessons

Open **Workflow_Visual_Comparison.html**. Choose **Videos & algorithms → Learn the algorithms**. The optional ten-lesson sequence connects unchanged external recordings with independently written code, worked examples, correctness arguments and questions for the literature review.

**Algorithm_Lessons.html** opens the lessons directly. **Workflow_Learning_Resources.html** retains the complete video and reading collection. **Workflow_Terms_and_Nomenclature.html** retains the glossary.

## What changed on 15 October 2026

Added ten algorithm companions and eight learning records: five university-linked videos and three primary technical references. The collection now has 63 resources (27 videos and 36 written records). A video-topic match is distinguished from an exact specialist-method explanation. No new research-paper review or verified novelty claim is implied.

The existing research records, historical lineage, glossary data, and research algorithm files are unchanged. Audit_Report.html describes the earlier research audit, not the new teaching-code checks. Earlier archived versions are historical snapshots.

## Run the teaching code

Python 3.10 or newer; standard library only:

```bash
python code/algorithm_foundations.py
python tests/check_algorithm_foundations.py
```

The companion functions explain adjacency lists, Kahn, DFS, fixed-priority Kahn, BFS reachability, a slow transitive-reduction reference, earliest finishes in a DAG, one-file consumer events, a full-recomputation insertion baseline and order validation. They are not new algorithms and do not implement every research paper. Use the retained original research code and sources for the specialist comparisons.

## Checks and limits

Read tests/algorithm_lessons/Revision_and_Verification.md and its JSON results. Browser tests require Playwright and Chromium; these packages are not needed to read the guide. Video playback and complete spoken content were not audited. Videos require internet, have no autoplay, and load only after selection. Code examples and stored explanations work offline.

Save comparison notes with the existing export controls. Saved comparison HTML retains algorithm lessons. Standalone HTML exports require no local server.

For content edits, code/update_html.py refreshes the embedded data, CSS and scripts. The add_algorithm_lessons.py and build_lessons_ui.py scripts record one-time migration steps; do not rerun them on an already patched page.
