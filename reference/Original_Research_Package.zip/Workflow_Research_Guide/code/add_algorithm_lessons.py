"""Extend the learning collection without replacing the research evidence."""
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
from algorithm_foundations import traces
p=ROOT/'data/Learning_Resources.json'
D=json.loads(p.read_text())
VTU='https://online.vtu.ac.in/v1/course-details/Design-and-Analysis-of-Algorithms'
NPTEL='https://nptel.ac.in/courses/106106131'
CHECK='2026-10-15'
new=[
 ('v-nptel-graphs','Representing graphs','Y-6IGzmlG4Y','13:46','Graph representation','Connect an edge list, an adjacency list and an indegree array.'),
 ('v-nptel-topological','Directed acyclic graphs: topological sort','_9a95v2shgQ','20:25','Topological sorting','Study dependency ordering, then trace the source-removal implementation in the companion.'),
 ('v-nptel-heapupdates','Heaps: Updating values, sorting','51pyj1NWEqI','12:00','Priority queues','Study heap updates before reading mutable scheduling priorities.'),
 ('v-nptel-longest','Directed acyclic graphs: longest paths','jpIeCsX4oNo','14:00','DAG dynamic programming','Understand propagation in topological order and the critical-path lower bound.'),
 ('v-nptel-checking','Checking Algorithms','btytfRFySg0','23:46','Verification','Introduce algorithm checking; use the independent local checks as a separate exercise.')]
existing={r['id'] for r in D['resources']}
for ident,title,yt,duration,topic,focus in new:
 if ident in existing:continue
 D['resources'].append({'id':ident,'title':title,'provider':'Madhavan Mukund · NPTEL, Chennai Mathematical Institute','url':VTU,'kind':'Video','topic':topic,'focus':focus,'limit':'University-linked recording. Title and embedded video ID were verified; the recording was not watched end to end. The accompanying Python code is independently written, not code copied from this lecture. No claim of research novelty follows.','year':None,'duration':duration,'youtube_id':yt,'level':'Core','checked':CHECK,'verification':'NPTEL course 106106131 establishes the course and instructor. VTU lists this lecture and its embedded video ID. External playback and every spoken claim were not verified. No unverified timestamps are supplied.','evidence_url':VTU,'secondary_evidence_url':NPTEL,'check_location':'University course page: named lecture and immediately following iframe. Duration is the displayed catalog value, not independently measured.'})
references=[
 ('d-transitive','Transitive reduction on a DAG','https://networkx.org/documentation/stable/reference/algorithms/generated/networkx.algorithms.dag.transitive_reduction.html','Reachability','Read the precise edge-redundancy condition and cyclic-input restriction.'),
 ('d-lexicographic','Lexicographical topological sorting','https://networkx.org/documentation/stable/reference/algorithms/generated/networkx.algorithms.dag.lexicographical_topological_sort.html','Topological sorting','Separate a valid order from a particular tie-breaking policy.'),
 ('d-xla-scheduler','XLA memory scheduler · tagged source','https://github.com/tensorflow/tensorflow/blob/v2.10.0/tensorflow/compiler/xla/service/hlo_memory_scheduler.cc','Priority maintenance','Read BytesFreedIfScheduled and CreateSchedule in a pinned source version.')]
for ident,title,url,topic,focus in references:
 if ident in existing:continue
 D['resources'].append({'id':ident,'title':title,'provider':'TensorFlow authors' if ident=='d-xla-scheduler' else 'NetworkX developers','url':url,'kind':'Reference','topic':topic,'focus':focus,'limit':'Primary implementation or documentation, not a video. A simplified teaching example does not reproduce the complete library or compiler.','year':2022 if ident=='d-xla-scheduler' else None,'youtube_id':None,'level':'Core','checked':CHECK,'verification':'XLA excerpt retained from the prior tagged-source audit; not a new compiler execution.' if ident=='d-xla-scheduler' else 'Official documentation reopened for the definition and behavior.','evidence_url':url,'check_location':'Named algorithm documentation, or the retained tagged scheduler functions.'})
code=(ROOT/'code/algorithm_foundations.py').read_text()
def snippet(name):return re.search(r'# BEGIN '+name+r'\n(.*?)# END '+name,code,re.S).group(1).strip()
T=traces()
def lesson(id,title,why,video,match,focus,steps,formula,proof,cost,warning,exercise,methods,refs,codekey=None,example=None,optional=False):
 return dict(id=id,title=title,why=why,video_id=video,video_match=match,watch_for=focus,steps=steps,formula=formula,proof=proof,cost=cost,warning=warning,exercise=exercise,methods=methods,references=refs,code=snippet(codekey) if codekey else '',code_label='Independent Python teaching code · standard method, not a proposed contribution',example=example or {},optional=optional)
L=[]
L.append(lesson('graph','Represent the dependency graph','Know exactly what an edge means before reading any scheduling method.','v-nptel-graphs','Lecture topic matches; companion independently checked','How the same graph becomes an adjacency list. Do not confuse successors with predecessors.',[
 'Treat u → v as “u must finish before v”.','Store successors in adj[u], then count incoming edges for each vertex.','Preserve isolated tasks; they are part of the input too.'
], 'indegree(v) = |{u : (u,v) ∈ E}|', 'Each edge contributes once to its target’s indegree. The array therefore records the number of unfinished prerequisites before execution starts.',
 'Adjacency construction and indegrees: O(n + m) expected with a hash set for duplicate checks. Stored graph: O(n + m).',
 'Python graphlib expects predecessor lists. This teaching module expects successor lists. Reversing that convention reverses the meaning of the workflow.',
 'How would you show that two graph representations encode the same prerequisites without relying on their vertex labels?', ['S1','S5'],['d-graphlib','d-networkx'],None,
 {'headers':['Task','Successors','Initial indegree'],'rows':[['A','C',0],['B','C',0],['C','D',2],['D','none',1],['E','none',0]],'caption':T['graph']}))
L.append(lesson('kahn','Kahn’s algorithm','Understand the eligibility rule that every priority-based variant must preserve.','v-nptel-topological','Topological-sorting lecture; source-removal code below is separately checked','Why a task with zero remaining indegree can be chosen, and why a queue avoids repeatedly searching every vertex.',[
 'Initialize a queue with every zero-indegree task.','Remove one task, append it to the order, and decrement each successor’s indegree.','Enqueue a successor only when its count becomes zero. Reject the graph if fewer than n tasks are output.'
], 'd_D(v) = |pred(v) ∖ D|;  choose only v with d_D(v) = 0.',
 'The indegree invariant makes each chosen task eligible. Removing its outgoing edges preserves the invariant. A nonempty residual DAG has a source, so an empty queue before completion implies a cycle.',
 'O(n + m) time with adjacency lists and a deque; O(n) auxiliary space beyond the graph and output.',
 'Kahn is not ordinary BFS. BFS discovering a task does not mean all its prerequisites are satisfied. Residual blocked tasks need not all lie on a cycle.',
 'Which operations are needed for eligibility, and which are only needed by an added selection policy?', ['S1','S2','S4'],['d-graphlib'],'kahn',
 {'headers':['Event','Ready queue','Indegrees A–E','Output'],'rows':[[r['event'],', '.join(r['ready']) or 'empty',str(r['degree']),', '.join(r['order']) or 'empty'] for r in T['kahn']],'caption':T['graph']}))
L.append(lesson('dfs','DFS ordering and cycle detection','Learn an independent way to verify ordering and detect cycles.','v-dfs','Direct algorithm topic','The active recursion stack, finish order, and the reason to reverse that order.',[
 'Mark a task active, then visit its unseen successors.','An edge to an active task is a directed-cycle witness.','Append a task only after its successors finish; reverse the complete finishing list.'
], 'For every edge u → v in a DAG, finish(v) < finish(u).',
 'If v is unseen, DFS finishes v before returning to u. If v is finished, its finish already precedes u’s. An active v would create a cycle, so that case is excluded in a DAG.',
 'O(n + m) time and O(n) auxiliary space. Recursive teaching code can hit Python’s recursion limit on deep graphs.',
 'Two valid topological algorithms can return different orders. That is not an error. Exact sequence equality is required only for implementations of the same policy and tie-break.',
 'What should a correctness oracle check when two valid algorithms intentionally use different traversal rules?', ['S5','D6'],['d-graphlib'],'dfs',
 {'headers':['Method','Valid output on the same graph'],'rows':[['FIFO Kahn',', '.join(T['kahn'][-1]['order'])],['DFS reverse postorder',', '.join(T['dfs_order'])]],'caption':T['graph']}))
L.append(lesson('priority','Heaps and priority-based Kahn','Separate the rule that permits a task from the rule that prefers it.','v-nptel-heapupdates','Heap-update lesson; priority-Kahn composition is the companion','Restoring the heap property after an insertion or key change. The video is not a reproduction of the XLA scheduler.',[
 'Keep Kahn’s indegrees and ready condition unchanged.','Store only ready tasks in a heap keyed by priority and a fixed tie-break.','For changing scores, update the heap correctly or invalidate stale entries; changing an unrelated score array is not enough.'
], 'v* = argmax { (score(v), −id(v)) : v ∈ R(D) }',
 'Every heap entry is eligible. The key selects one eligible task, so topological validity is preserved. Heap ordering must reflect the current key to preserve the intended policy.',
 'Fixed-score example: O(m + n log n) time and O(n) extra storage. Dynamic priorities add update and stale-entry costs; the fixed-score bound does not cover them.',
 'A heap does not improve FIFO Kahn’s linear asymptotic bound. It implements a different selection policy. Lazy stale entries can increase memory.',
 'Is the real cost in calculating a score, locating affected tasks, or refreshing the queue? What measurement would distinguish them?', ['S3','P1','E20','E29','E30'],['v-heaps','d-heap','d-lexicographic'],'priority',
 {'headers':['Policy','Order'],'rows':[['FIFO','A, B, E, C, D'],['Fixed priorities A=2, B=5, C=4, D=6, E=1',', '.join(T['priority_order'])]],'caption':'Same dependencies, different policy. Both outputs are valid.'}))
L.append(lesson('reachability','BFS reachability and redundant edges','Learn what actually certifies that one prerequisite implies another.','v-bfs','Direct BFS lesson; transitive reduction requires the linked reference','Visited sets and systematic edge exploration. A stopped search is not proof that a path does not exist.',[
 'Search from u through successors to test whether v is reachable.','To test whether edge u → v is redundant, exclude that edge during the search.','Keep the edge unless an alternative path has been proved. A budget-limited search needs a distinct “unknown” result.'
], 'Remove (u,v) only if u reaches v in G without that edge.',
 'The alternative path preserves the same precedence implication. In a finite DAG, its transitive reduction preserves reachability. This does not license deleting file-use metadata with different semantics.',
 'One BFS: O(n + m) worst case. The clear per-edge reference below costs O(n + m + m(n + m)); it is not an optimized baseline.',
 'The companion reduces graph edges, not release counters. A counter reduction needs its own ready-score equivalence proof. Do not present this existing technique as a new idea.',
 'Which easily checked properties might avoid an expensive search, and how would you measure the cost of those checks?', ['P3','P4','E08','M9','D4'],['d-transitive'],'reduction',
 {'headers':['Input edges','Result','Reason'],'rows':[['A → B, B → C, A → C','A → B, B → C','A → B → C replaces the direct A → C implication']],'caption':'The original graph is a DAG. The full module includes the BFS helper.'}))
L.append(lesson('critical','Longest paths and critical-path reasoning','Recognize the difference between ordering overhead and workflow completion time.','v-nptel-longest','Direct DAG longest-path topic','Values passed along a topological order, rather than a search over arbitrary paths.',[
 'Give each task a nonnegative duration.','Process tasks in topological order and propagate the largest predecessor finish time.','Interpret the result under its resource assumptions before using it as a scheduling objective.'
], 'finish(v) = duration(v) + max({finish(u) : u ∈ pred(v)} ∪ {0})',
 'A topological order processes every predecessor before v. Induction along that order makes finish(v) the earliest finish under unlimited processors, zero communication delay, and the stated durations.',
 'O(n + m) time and O(n) auxiliary space.',
 'This is not HEFT. Heterogeneous processors, communication costs and insertion-based placement require the original HEFT method. A critical path alone is not a finite-resource schedule.',
 'Which metric would change if an ordering algorithm ran faster but returned exactly the same task order?', ['M5','M6','M7','S4'],['v-dag'],'criticalpath',
 {'headers':['Task','Duration','Earliest finish'],'rows':[[chr(65+i),t,T['critical_finish'][i]] for i,t in enumerate([2,3,4,1,2])],'caption':T['graph']},True))
L.append(lesson('counting','Reference counts and memory-aware list scheduling','Read the actual mechanism our early proposal overlapped with.','v-heaps','Prerequisite video only; exact XLA algorithm is in the pinned source','Heap selection and update mechanics first. Then read BytesFreedIfScheduled and CreateSchedule in the actual XLA source.',[
 'Count each distinct unfinished task that consumes an intermediate file.','Credit a ready task only when it is the file’s last unfinished consumer.','After one completion, a count changing from two to one identifies a possible new release credit.'
], 'score_D(v) = −created(v) + Σ_f bytes(f) · 1[v ∈ C_f and |C_f ∖ D| = 1]',
 'For a surviving consumer, the predicate “only unfinished consumer” can switch from false to true only at a two-to-one transition. Initial single-consumer cases need credit at initialization.',
 'One simple file-counter pass inspects total consumer incidences I = Σ_f |C_f|. Total scheduler time also includes score lookup, initialization and queue operations.',
 'No dedicated XLA memory-scheduler walkthrough was verified. The code below is an isolated counting example, not the full scheduler. Reference counting, the priority formula and this event trigger already exist.',
 'What information must remain exact for the next ready-task choice, and what would an experiment have to show before claiming less maintenance work?', ['E20','E29','E30','P0','P1','M8'],['d-xla-scheduler','d-heap'],'counter',
 {'headers':['Completion','Unfinished consumers','New credit'],'rows':[[r['finished'] if r['finished'] is not None else 'Start',str(r['remaining']),(str(r['credit_to'])+' gets '+str(r['credit'])) if r['credit_to'] is not None else 'none'] for r in T['consumer_events']],'caption':'One 8-byte file; consumers 0, 1 and 2. All are initially ready. Credits in bytes; no storage-speedup claim.'}))
L.append(lesson('incremental','When an edge changes the order','Distinguish incremental graph ordering from incremental score maintenance.','v-dfs','Prerequisite video only; no dedicated Pearce–Kelly video verified','Reachability and cycles. The actual incremental repair method remains in its paper, not this DFS lecture.',[
 'Given a valid order, a new edge u → v already fits if u precedes v.','For a backward edge, a pre-existing path v → u proves that the insertion creates a cycle.','Otherwise repair the order. The teaching baseline below recomputes; Pearce–Kelly instead searches and reassigns affected vertices.'
], 'A new u → v creates a cycle iff u = v or v already reaches u.',
 'Any newly introduced cycle must use the new edge; removing that edge leaves a path v → u. Conversely, such a path together with u → v is a cycle.',
 'Teaching baseline: O(n + m) per call, including validity checking and copying. It does not achieve Pearce–Kelly’s update behavior or the constant-time fast path of a maintained production index.',
 'Completing a task in a fixed workflow does not insert an edge. Do not transfer incremental-edge complexity bounds to priority bookkeeping.',
 'Does your intended application change graph edges, task states, or only priority metadata? Which existing methods truly share that input model?', ['D1','D2','D3','D4','D5','D10','D11','D7','D8','D9'],['v-bfs'],'insertion',
 {'headers':['Existing order','New edge','Consequence'],'rows':[['A, B, C with A → B → C','A → C','Order remains valid'],['A, B, C with A → B → C','C → A','Creates a cycle']],'caption':'A graph-update example, not the fixed-Montage experiment.'},True))
L.append(lesson('proof','Prove the invariant and check the code','Use mathematics and an independent check for different purposes.','v-induction','Proof foundation, not a proof of the students’ future method','Base case, induction hypothesis, preserved step and termination.',[
 'State exactly which property must stay unchanged after each step.','Prove the initial state and one transition, then show that the process terminates.','Test an implementation against an independent reference and intentionally invalid cases.'
], 'Same prefix + same ready priorities + same tie-break ⇒ same next task.',
 'Induction yields the same complete sequence only when all three conditions hold. Valid topological order alone does not establish equivalence to a particular priority policy.',
 'Checking one completed order takes O(n + m) time and O(n) auxiliary space. The cost of a proof is not an empirical runtime metric.',
 'Passing random tests is not a universal proof, and a correct standard implementation is not novel merely because students implement it.',
 'What is the smallest input that could falsify your claim, and is your checker independent of the proposed implementation?', ['S1','S5','P0','P1','P4'],['v-states','v-nptel-checking','d-tests'],'validate',
 {'headers':['Claim','Required check'],'rows':[['Valid order','All vertices exactly once; all edges forward'],['Equivalent policy','Same ready priorities and fixed tie-break'],['Historical novelty','Exact mechanism compared with closest prior art']],'caption':'These are three distinct claims; none substitutes for the others.'}))
L.append(lesson('measure','Analyze and measure the complete cost','Derive improvements from a measured bottleneck instead of a renamed algorithm.','v-measure','Measurement foundation; not an algorithm-specific performance result','Setup cost, timing variability and the boundary around the operation being measured.',[
 'Count graph work, preprocessing and priority maintenance separately.','Measure the complete operation under the same representation and input assumptions.','Include cases with no opportunity for the modification and cases where overhead dominates.'
], 'T_preparation + T_modified ordering < T_reference ordering',
 'The inequality is the condition for a one-shot runtime benefit. Reducing one internal counter does not imply it. A better Big-O bound and a measured constant-factor improvement are separate claims.',
 'Two thesis metrics: complete order-construction time and a precisely defined operation count. Correctness remains mandatory.',
 'No GPU is needed for these metadata experiments. Do not claim faster image processing, guaranteed novelty, or Montage speedups from a synthetic trace.',
 'Which baseline could make your improvement disappear? Include that baseline before selecting the final rule.', ['P1','P2','P3','P4','P5','E29','E30'],['v-work','d-pyperf','d-timeit'],None,
 {'headers':['Measure','Include'],'rows':[['Ordering time','All method-specific preprocessing and initialization'],['Counter updates','Define decrements, inspections and queue updates separately'],['Evidence','Per-instance differences, variability and regressions']],'caption':'A study plan, not measured performance.'}))
D['algorithm_lessons']=L
D['algorithm_module']={'title':'Learn the algorithms','checked':CHECK,'scope':'A suggested sequence of prerequisites and tested companions. Not a prescribed new algorithm or a certification of novelty.','video_scope':'University-linked recordings are unchanged. Companion code and examples are independently written. No full end-to-end video audit or playback certification was performed.','order':[x['id'] for x in L],'code_file':'algorithm_foundations.py','notation':'n = number of tasks; m = number of dependency edges; I = number of file-consumer incidences.'}
# Show explicit foundation routes without claiming dedicated videos for specialist methods.
for kind in ['method_routes','source_routes','term_routes']:
 for key,r in D[kind].items():
  text=(r.get('title','')+' '+r.get('full','')).lower()
  matched=[x['id'] for x in L if key in x['methods']] if kind=='method_routes' else []
  if not matched:
   if any(t in text for t in ['kahn','topologicalsorter','fifo','lifo','indegree']):matched=['kahn','priority']
   elif any(t in text for t in ['pearce','ahrsz','katriel','incremental topological','strong component','mnr','prediction','ajwani','cycle detection']):matched=['dfs','incremental']
   elif any(t in text for t in ['xla','hlo','consumer','counter','reference count','live-out','live out','bytes freed','release credit']):matched=['counting','priority']
   elif any(t in text for t in ['heap','priority','queue']):matched=['priority','kahn']
   elif any(t in text for t in ['reach','transitive','precedence','cleanup','prun']):matched=['reachability','counting']
   elif any(t in text for t in ['heft','critical','longest path','schedule','scheduling','pebbl','dataflow','memory-aware']):matched=['critical','counting']
   elif any(t in text for t in ['dfs','depth-first']):matched=['dfs','reachability']
   elif any(t in text for t in ['bfs','breadth-first']):matched=['reachability','kahn']
   elif any(t in text for t in ['proof','invariant','induct','equivalen']):matched=['proof']
   elif any(t in text for t in ['time','benchmark','amort','complexity','big-o','asymptot']):matched=['measure']
   elif any(t in text for t in ['graph','dag','vert','edge','adjacen']):matched=['graph','kahn']
  # Every named method gets useful prerequisites, not a fictional exact tutorial.
  if kind=='method_routes' and not matched:matched=['graph','proof','measure']
  r['algorithm_lessons']=list(dict.fromkeys(matched))
  if kind=='method_routes' and key.startswith('D'):
   r['note']='No dedicated walkthrough of this exact research method was verified. Start with the graph-update lesson, then use the original method source below.'
  if matched:
   suggested=[]
   for lid in matched:
    v=next(x['video_id'] for x in L if x['id']==lid)
    if v:suggested.append(v)
   r['resources']=list(dict.fromkeys(r['resources']+suggested))
# Keep ordinary tutorial videos from being mistaken for the exact research implementation.
for r in D['resources']:
 r['algorithm_lessons']=[x['id'] for x in L if r['id']==x['video_id'] or r['id'] in x['references']]
D['counts']['videos']=sum(x['kind']=='Video' for x in D['resources'])
D['counts']['written']=sum(x['kind']!='Video' for x in D['resources'])
D['counts']['algorithm_lessons']=len(L)
D['counts']['total']=len(D['resources'])
D['verification_policy']['algorithm_companions']='Ten algorithm lessons connect unchanged external videos to independent Python teaching examples, invariants, complexity notes and research questions. Dedicated-video gaps are explicit. Local tests check examples, not the entire external recordings or research novelty.'
D['verification_policy']['matching']='A lecture-topic match is not a full video-content audit. Direct algorithm lessons, prerequisite videos and source-only specialist methods are labeled separately. The companion implementation is not claimed to be the lecturer’s code.'
p.write_text(json.dumps(D,ensure_ascii=False,indent=2))
(ROOT/'data/Algorithm_Lessons.json').write_text(json.dumps({'module':D['algorithm_module'],'lessons':L},ensure_ascii=False,indent=2))
print(len(L),'lessons;',D['counts'])
