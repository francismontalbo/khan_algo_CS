"""Timing harness for validated Workflow objects. The CLI uses SYNTHETIC data.

No speedup claim is supplied with this template. To test Montage, first map a
frozen trace into Workflow and validate the producer and consumer semantics.
"""
from __future__ import annotations
import argparse
import gc
import json
import platform
import random
from pathlib import Path
from statistics import median
from time import perf_counter_ns
from workflow_methods import (Workflow, per_file_groups, aggregate_equal,
    reduce_consumers, direct_certificates, incremental)
from run_checks import fixture


def benchmark(w: Workflow, repetitions: int = 20, budget: int = 8) -> dict:
    if repetitions < 2:
        raise ValueError("use at least two repetitions")
    w.validate()  # Common validation, not an unreported proposed-method cost.
    def execute(name: str):
        groups = per_file_groups(w)  # Method preparation starts here.
        if name == "equal_consumers":
            groups = aggregate_equal(groups)
        elif name == "direct_certificates":
            groups = direct_certificates(w, groups).groups
        elif name == "full_maximal":
            groups = reduce_consumers(w, groups, None).groups
        elif name == "bounded":
            groups = reduce_consumers(w, groups, budget).groups
        return incremental(w, groups, audit=False)
    names = ["per_file", "equal_consumers", "direct_certificates", "full_maximal", "bounded"]
    for name in names:
        execute(name)  # Identical warm-up count; do not reuse mutable state.
    times = {name:[] for name in names}
    counts = {}
    rng = random.Random(20261014)
    for _ in range(repetitions):
        order = names.copy()
        rng.shuffle(order)
        for name in order:
            gc.collect()
            enabled = gc.isenabled()
            gc.disable()
            try:
                start = perf_counter_ns()
                result = execute(name)
                elapsed = perf_counter_ns() - start
            finally:
                if enabled:
                    gc.enable()
            times[name].append(elapsed)
            counts[name] = result.counter_decrements
    return {"python":platform.python_version(), "platform":platform.platform(),
            "runs_per_method":repetitions, "budget_edge_inspections":budget,
            "raw_time_ns":times, "median_time_ns":{k:median(v) for k,v in times.items()},
            "counter_decrements":counts,
            "scope":"Includes grouping, searches, initialization, and order construction. "
                    "Excludes common input validation, parsing, and debug score histories."}

if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs",type=int,default=20)
    parser.add_argument("--out",type=Path,default=Path("synthetic_timing.json"))
    args=parser.parse_args()
    result=benchmark(fixture("ordered consumers"),args.runs)
    result["input_kind"]="synthetic demonstration, NOT Montage"
    args.out.write_text(json.dumps(result,indent=2)+"\n")
    print(f"Wrote synthetic demonstration measurements to {args.out}")
