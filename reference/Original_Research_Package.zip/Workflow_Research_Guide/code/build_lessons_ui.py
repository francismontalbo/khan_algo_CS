from pathlib import Path
import json
from bs4 import BeautifulSoup
R=Path(__file__).resolve().parents[1]
f=R/'code/learning.js';s=f.read_text()
insert=(R/'code/algorithm_lessons_ui.js').read_text()
s=s.replace("function resources(){",insert+"\nfunction resources(){",1)
s=s.replace("function renderList(){stopVideo();", "function renderList(){dialog.classList.remove('algorithm-open');stopVideo();",1)
s=s.replace("list.innerHTML=intro+suggestions()", "list.innerHTML=(r?lessonLinks(r):algorithmBanner())+intro+suggestions()",1)
s=s.replace("function showResource(id,trigger=null){const r=", "function showResource(id,trigger=null){dialog.classList.remove('algorithm-open');const r=",1)
s=s.replace("panel.scrollTop=0;$('learning-resource-heading').focus({preventScroll:true});}", "detail.insertAdjacentHTML('beforeend',lessonLinks(r)); panel.scrollTop=0;$('learning-resource-heading').focus({preventScroll:true});}",1)
s=s.replace("function showPolicy(){show();", "function showPolicy(){dialog.classList.remove('algorithm-open');show();",1)
s=s.replace("['Internet and privacy','network']", "['Internet and privacy','network'],['Algorithm lessons','algorithm_companions']",1)
s=s.replace("<button data-open-learning>Browse learning resources</button>", "<button data-open-algorithms>Learn the algorithms</button> <button data-open-learning>Browse learning resources</button>",1)
s=s.replace("window.workflowLearning={open,close,showResource", "window.workflowLearning={openAlgorithms,showLesson,algorithmStandalone,lessonIds:LESSONS.map(x=>x.id),open,close,showResource",1)
f.write_text(s)
d=json.loads((R/'data/Learning_Resources.json').read_text());d['counts']['resources']=len(d['resources']);d['algorithm_module']['python']=(R/'code/algorithm_foundations.py').read_text();(R/'data/Learning_Resources.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
h=R/'Workflow_Visual_Comparison.html';text=h.read_text();text=text.replace('Videos &amp; tutorials</button>','Videos &amp; algorithms</button>')
h.write_text(text)
print('Updated teaching interface')
