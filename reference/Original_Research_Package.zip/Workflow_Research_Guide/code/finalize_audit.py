from pathlib import Path
from bs4 import BeautifulSoup
import json, csv, html, hashlib, shutil
R=Path(__file__).resolve().parents[1]; DATE='2026-10-15'
D=json.loads((R/'data/Explorer_Data.json').read_text()); L=json.loads((R/'data/Learning_Resources.json').read_text())
queries=[
'2026 memory scheduling DAG topological ordering schedule construction overhead',
'2026 "XLA" "memory scheduler"','2026 "workflow" "reference counting"','2026 "incremental topological"',
'"memory" "scheduling" "2026" "peak"','"topological ordering" "2026" algorithm','"scheduling" "metadata" "overhead" "2026"','"Balancing Tracking Granularity and Parallelism"',
'"dominant schedules" "memory"','"memory" "scheduling" "2026" "DAG" "minimization"','"workflow" "counter" "scheduling" "overhead"','"dag scheduling" "benchmarking" evaluation reproducibility',
'"New Tools for Peak Memory Scheduling" publication','"Dependency-Aware Cache Management for Data Analytics Clusters" 2022','"Scheduling series-parallel task graphs to minimize peak memory" authors','"Benchmarking DAG Scheduling Algorithms" authors 2024',
'"New Tools for Peak Memory Scheduling" Jin','"Benchmarking DAG Scheduling Algorithms"','"Dependency-Aware Cache Management" "2022"','"Guidelines for snowballing" Wohlin 2014',
'"Scheduling series-parallel task graphs" "Kayaaslan"','"Towards Dependency-Aware Cache Management" "10."','"Topological Sorting of Large Networks" "Kahn" 1962','"Optimizing Workflow Data Footprint" "Scientific Programming"']
log=[dict(id=f'Q{i+1:02}',date=DATE,channel='Web search',query=q,purpose='Discovery, conflicting evidence, date or bibliographic verification',limit='Search results are ranked and not a complete database export; a zero result is not evidence of absence.') for i,q in enumerate(queries)]
log.append(dict(id='S01',date=DATE,channel='SciSpace',query='What primary studies from 2024 through 15 October 2026 investigate the computational overhead of constructing or maintaining dependency-respecting task schedules, especially memory-aware list scheduling, remaining-use counters, reachability-based reductions, or scheduling metadata, and what negative results or preprocessing costs do they report?',purpose='Semantic discovery; metadata checked against primary sources before use.',limit='One returned page of ten candidates; no exhaustive index retrieval. Index metadata is not authoritative.'))
log.append(dict(id='G01',date=DATE,channel='GitHub connector',query='https://api.github.com/repos/openxla/xla/commits?path=xla/hlo/transforms/simplifiers/hlo_memory_scheduler.cc&per_page=10&until=2026-10-15T23:59:59Z',purpose='Check latest changes to the particular scheduler file by the cutoff.',limit='One file and ten commits, not the complete compiler history. The day is a date filter, not a claim to know later events.'))
(R/'data/Audit_Search_Log.json').write_text(json.dumps({'cutoff':DATE,'review_type':'Retrospective audit and targeted update','original_search_history':'Not recoverable in full from the retained artifact','dual_screening':False,'queries':log},indent=2,ensure_ascii=False))
# Borderline retrieved candidates are recorded even when not turned into comparison columns.
# These are explicit screened candidates, not an asserted total of all returned search hits.
candidates=[]
for s in D['sources']:
 if s['id']=='E25':continue
 candidates.append(dict(id=s['id'],title=s['title'],year=s.get('year'),url=s.get('url'),decision='Retained' if s['id'] not in ['E31','E32','E33','E34','E35','E36'] else 'Added',role=s.get('role','Context'),reason='Relevant foundation, direct mechanism, model boundary, practical comparison, or supporting resource. See the source model and audit level.',evidence=s['audit_level'],family=s['evidence_family']))
extras=[
('A Reservation-Based List Scheduling for Embedded Systems with Memory Constraints',2023,'https://doi.org/10.1007/978-3-031-29927-8_12','Context lead; not a main timing comparator','Targets feasibility and deadlock under memory constraints; not exact maintenance of a fixed priority policy. Abstract-only lead.'),
('Resource-Aware Task Scheduling',2015,'https://doi.org/10.1145/2638554','Context lead; full follow-up pending','Runtime resource contention differs from sequential order-construction cost; keep as related work rather than a numerical baseline.'),
('A Soft-Real-Time Optimal Scheduler for DAG Tasks with Node-Level Self Dependencies',2025,'https://doi.org/10.1109/RTSS66672.2025.00019','Outside main comparison','Repeated overlapping real-time graph invocations and response-time guarantees differ from a fixed single execution.'),
('BEMOS: A Beam Exploration Framework for Energy and Makespan Optimization in Heterogeneous Multiprocessor Scheduling',2025,'https://doi.org/10.1109/ICPADS67057.2025.11323065','Outside main comparison; algorithmic lead','Changes assignment and optimizes energy and makespan. Excluded from timing ranking because output and objective differ, not because it reports success.'),
('Learning-Augmented Energy-Aware List Scheduling for Precedence-Constrained Tasks',2024,'https://doi.org/10.1145/3680278','Context lead; not a main comparator','Changes a learned scheduling objective and energy trade-off. Not excluded from novelty review merely because it uses learning.'),
('Near-Optimal Cache Sharing through Co-Located Parallel Scheduling of Threads',2025,'https://doi.org/10.1145/3770858','Outside main comparison','Fork-join thread co-location, schedulability and core requirements differ from the proposed output contract.'),
('From HEFT to IKHeft: Optimization Algorithm for Efficient Cloud Task Scheduling',2026,'https://doi.org/10.1145/3796315.3796318','Context lead; access limited','Primary search result located; full publisher retrieval failed. VM assignment changes are not exact-order maintenance. Do not claim its absence or transfer its speedup.'),
('Resource-efficient scheduling of parallel DAG tasks on identical multiprocessors',2026,'https://doi.org/10.1016/j.sysarc.2026.103775','Outside main comparison','Parallel resource allocation and real-time feasibility differ; full method not audited.'),
('Peak-memory-aware partitioning and scheduling for multi-tenant DNN model inference',2026,'https://doi.org/10.1016/j.sysarc.2026.103696','Context lead; not a main comparator','Partitioning and multi-tenant execution change granularity and hardware assumptions. Preserve as a model-boundary lead.'),
('Workload-Aware Performance Evaluation of Sequential and Parallel DAG-Based Machine Learning Orchestration on Single-Node Systems',2026,'https://jurnal.polgan.ac.id/index.php/sinkron/article/view/15788','Context lead; methods review pending','Primary abstract reports workload-dependent performance, but system differences are not isolated algorithmic effects. Detailed methods not reviewed; do not use the numerical result as a verified benchmark.'),
('Command Horizons: Coalescing Data Dependencies While Maintaining Asynchronicity',2023,'https://link.springer.com/article/10.1007/s42979-024-02749-w','Grouped with E31; earlier version pending','The 2024 article identifies this preceding chapter. Avoid counting the line as two independent replications; exact chapter full text remains to be obtained.'),
]
for i,(title,year,url,decision,reason) in enumerate(extras,1):candidates.append(dict(id=f'L{i:02}',title=title,year=year,url=url,decision=decision,role='Screened follow-up lead',reason=reason,evidence='Primary discovery metadata or abstract only; see reason.',family='E31 line' if i==11 else title))
(R/'data/Audit_Screening_Log.json').write_text(json.dumps({'cutoff':DATE,'note':'Explicitly logged decisions for retained sources and selected retrieved borderline leads. Not an exhaustive hit log; no PRISMA counts or recall estimate are claimed. Result direction was not an exclusion criterion.','records':candidates},indent=2,ensure_ascii=False))
with (R/'data/Audit_Screening_Log.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=candidates[0].keys());w.writeheader();w.writerows(candidates)
checks={
 'scope':{'cutoff':DATE,'source_records':len(D['sources']),'external_records':D['counts']['external'],'independent_study_count':'Not inferred from record count','compare_entries':D['counts']['comparable'],'historical_lineage':37,'terms':248,'lessons':55},
 'material_repairs':[
  {'issue':'No reproducible selection record','status':'Partially repaired','repair':'Added actual current queries, explicit borderline decisions, source families and inclusion rules. Original search history and independent screening remain missing.'},
  {'issue':'Relevant metadata-cost and model-boundary work missing','status':'Repaired for named omissions','repair':'Added Horizons, dominant schedules, joint scheduling and two 2026 preprints; no claim of exhaustive retrieval.'},
  {'issue':'XLA parent misattributed dense indexed representation','status':'Repaired','repair':'E30 not_new and linked records corrected; E29 is the indexed version.'},
  {'issue':'Bibliographic placeholders and ambiguous dates','status':'Partially repaired','repair':'Author and venue fields supplied from primary records; ambiguous final issue dates are explicit, not guessed.'},
  {'issue':'Local tests always recorded 14 October','status':'Repaired','repair':'Execution timestamp now comes from the UTC clock; original historical logs remain.'},
  {'issue':'Local validation source pointed at absent files','status':'Repaired','repair':'Source locator now names results/checks.json and the runnable test script.'}],
 'limits':['Single-assessor screening. No complete retrieval export or independent duplicate screening.','Not all primary sources fully read. Evidence depth recorded per source.','No faithful code reproduction for every paper. No real Montage timing.','Finite tests on intentionally structured synthetic workflows are not an unbiased performance sample.','External videos were not audited end to end. Four primary learning pages were re-opened, not all 55 resources.','PDF page screenshots were attempted for selected manuscript evidence but rendering failed; textual evidence only, no new plot extraction.','Interface exercised in Chromium with injected HTML and emulated narrow viewport. All cross-products and Safari not tested.'],
 'checked_source_metadata_examples':['Kahn publisher citation','Singh author institution record','Papp primary three-author list corrected relative to discovery index','RuSCDays 2023 versus January 2024 online date distinguished','LRC September 2019 author record versus unconfirmed final issue year'],
 'tutorial_page_sample':['https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-fall-2011/resources/lecture-14-depth-first-search-dfs-topological-sort/','https://openxla.org/xla','https://pyperf.readthedocs.io/en/latest/analyze.html','https://pegasus.isi.edu/documentation/user-guide/tutorial.html']}
(R/'data/Audit_Findings.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
# Embedded concise search log, with no new page and no mandatory gate.
p=R/'Workflow_Visual_Comparison.html';soup=BeautifulSoup(p.read_text(),'html.parser');slot=soup.find(id='audit-search-record');slot.clear()
inner='<div class="audit-search-list">'+''.join(f'<p><b>{html.escape(x["id"])} · {html.escape(x["channel"])}</b><br>{html.escape(x["query"])}</p>' for x in log)+'</div><p><strong>Screened leads not used as direct comparators</strong></p><div class="audit-search-list">'+''.join(f'<p><a href="{html.escape(x["url"])}" target="_blank" rel="noopener">{html.escape(x["title"])}</a><br>{html.escape(x["reason"])}</p>' for x in candidates if x['id'].startswith('L'))+'</div>'
slot.append(BeautifulSoup(inner,'html.parser'))
for node in soup.find_all(string=True):
 if node.parent.name in ('script','style'):continue
 txt=str(node)
 if '29 external records and one earlier local test record.' in txt:node.replace_with(txt.replace('29 external records and one earlier local test record.','35 external records and one local validation record. Multiple versions are not independent studies.'))
 if txt=='30 records':node.replace_with('36 records')
 if 'Review revised 14 October 2026' in txt:node.replace_with(txt.replace('Review revised 14 October 2026','Audit updated 15 October 2026'))
 if 'This revision used SciSpace for discovery, then checked primary papers' in txt:node.replace_with('The earlier reader added three comparative studies. This audit adds a targeted search update and explicit review-status records; see Review status for exact scope and exclusions.')
 if 'Other retained records state their earlier evidence level.' in txt:node.replace_with('The closest implementation and model assumptions were rechecked. Each source now states the depth of this audit. Abstract-only access is not a full methods review, and no real-workflow performance experiment was run.')
# Move new references into an explicit group before the existing no-results message.
ref=soup.find(id='references');g=soup.new_tag('div',attrs={'class':'source-group'});h=soup.new_tag('h3');h.string='Added in the 15 October audit';g.append(h)
for sid in ['E31','E32','E33','E34','E35','E36']:g.append(soup.find(id='ref-'+sid).extract())
soup.find(id='no-sources').insert_before(g)
# Link a concise independent audit note without forcing readers into it.
a=soup.new_tag('a',href='#review-audit');a.string='Review status'
# Ensure inherited misleading source note does not claim full coverage.
p.write_text(str(soup))
# Preserve original main page exactly as the audit starting snapshot.
# The unchanged audit input is already retained in archive/Before_15_October_Audit.html.
# Readable report is a small sidecar, not another navigation system.
report='''# Literature review audit

**Status: Share as a research guide with caveats. Not yet a complete systematic review or evidence of a novel tested algorithm.**

Cutoff: 15 October 2026. Events after this date and the remainder of 2026 are outside the audit.

## What was checked

The full local page structure, comparison data, lineage data, glossary and learning links were inventoried. The interface tests cover all definitions, method-learning views and resource detail pages, plus the comparison, source preview, tree, exports and narrow-layout paths. Repetitive paths share code; every possible combination was not independently inspected.

Primary-source review concentrated on claims that change the thesis decision: XLA priority updates and its September 2026 representation change, Singh et al.’s cleanup reduction, memory-model compatibility, actual comparative findings, and newer scheduling research. Every source record carries an audit level. Sources with only abstracts were not relabeled as full-text verified.

## Material repairs

- Corrected attribution of dense indexing to the later XLA revision rather than its predecessor.
- Added omitted metadata-management work (Horizons), the shared-output memory-model boundary (Jin et al.), a joint scheduling result, and July and October 2026 preprints. Their different objectives are explicit.
- Replaced bibliographic placeholders with primary metadata where available; online versus issue dates remain separate. Unresolved final dates are still flagged.
- Added the actual update queries, specific borderline inclusion decisions, evidence-family labels, and reasons for excluding unlike methods from a numerical comparison. The original search history cannot be reconstructed in full.
- Corrected a hardcoded date in the local test runner and repaired invalid paths to test results. Algorithm code was otherwise not changed.

## What prevents a no-cherry-picking claim

This is a single-assessor retrospective audit with ranked search results, incomplete historical retrieval records and limited full-text access. It cannot establish complete retrieval or zero selection bias. The added log makes future decisions inspectable; it does not retroactively make the earlier collection systematic.

Before the final thesis review, two students should independently screen borderline records; agree explicit criteria; search backwards and forwards from the closest studies; retain unfavorable and null results; group repeated versions; and record inaccessible studies rather than treating them as absent. Search again for the students’ precise eventual mechanism.

No comparison should combine peak memory, cache-hit rate, total workload time and scheduler construction time as if they were the same metric. A compiler buffer is not automatically a workflow file. Different shared-output and edge-output models can yield different tractability results.

## 2026 coverage

The existing average-memory and predicted strong-component records remain with their access limits. The XLA scheduler’s latest inspected file change by the cutoff is 25 September 2026. DAN-Scheduler (19 July) and MoSAIC (10 October) are included as preprints, not certified peer-reviewed results. Other recent, differently scoped leads remain in the screening log. This is current targeted coverage, not an exhaustive census of 2026 publications.

## What the guide can support

It can help students define one precise computational problem, identify close prior art, avoid invented novelty, formulate a falsifiable question, establish a correctness contract, and plan a CPU-only benchmark. It cannot select an entirely new algorithm by elimination from an incomplete source collection.

The proposal still needs its own exact rule and local evidence that the targeted cost matters. Keep total order-construction time as the primary metric and counter-update work as the explanation. Include preparation costs, competent simple controls, all selected workflow cases and unsuccessful runs. Do not turn repeated timing runs into additional independent workflows.

## Remaining substantive gaps

1. Several close and contextual records remain abstract-only. Complete their full-method extraction before using detailed claims.
2. Full original Montage JSON inputs and content hashes were not obtained here; no real Montage timing improvement is demonstrated.
3. The students’ eventual modification and an independent novelty check remain open.
4. Videos were not watched end to end, live playback was not verified and only a sample of four official learning pages was reopened in this audit.
5. Browser checks used Chromium injected HTML and emulated touch. File-origin behavior and Safari were not independently tested.
6. PDF screenshot rendering failed for selected manuscripts. Textual evidence was inspected; no new chart values were extracted.

## Reproduction and files

- `data/Audit_Search_Log.json`: actual queries and their limits.
- `data/Audit_Screening_Log.csv`: retained records and explicit borderline leads.
- `data/Audit_Findings.json`: repairs, limitations and learning-page sample.
- `data/Explorer_Data.json`: per-source audit levels and family labels.
- `results/checks.json`: current synthetic test results.
- `tests/current_audit`: interface logs and new audit checks.
- `archive/Before_15_October_Audit.html`: unchanged audit input.

Run `python code/run_checks.py --cases 5000` to reproduce the finite correctness suite. The test graph generator intentionally creates repeated consumer patterns; its outputs are not an unbiased workload-performance sample.

## Methodological source

Wohlin, Mendes, Felizardo and Kalinowski, “Guidelines for the Search Strategy to Update Systematic Literature Reviews in Software Engineering,” author preprint arXiv:2006.05542. The primary abstract supports citation-based update searching and highlights more than one assessor for selection. It does not certify this audit’s completeness.
'''
(R/'Audit_Report.md').write_text(report)
(R/'README.md').write_text('''# Workflow literature comparison — audited edition

Open **Workflow_Visual_Comparison.html** in a browser. The existing visual comparison, glossary, lessons and notes remain. **Review status** explains the audit and unresolved evidence.

The page embeds its data and scripts. External papers and videos need internet. No video loads automatically. Save notes using the existing export controls.

Scope: 35 external records, one local validation record, 58 selectable method or context entries, 37 historical entries, 248 term definitions, and 55 learning resources. These counts are not counts of independent scientific studies or proof of exhaustive coverage.

The current source update ends on 15 October 2026. No verified novel algorithm or real Montage speedup is claimed.

Read Audit_Report.md for the findings and data/Audit_Search_Log.json for the actual update search. Run python code/run_checks.py --cases 5000 for the finite local correctness checks.

Archived pages retain earlier statements and are historical snapshots, not the current evidence assessment.
''')
print('Finalized selection log:',len(log),'search actions;',len(candidates),'logged source/lead decisions. No recall estimate.')
