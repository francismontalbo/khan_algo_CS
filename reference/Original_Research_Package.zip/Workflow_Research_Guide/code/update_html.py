"""Refresh embedded assets without matching HTML-like strings inside JavaScript.

Run from any directory: python code/update_html.py
The original source records, reading notes and algorithm files are not rewritten.
"""
from html.parser import HTMLParser
from pathlib import Path
import json

class Blocks(HTMLParser):
    def __init__(self, text: str):
        super().__init__(convert_charrefs=False)
        self.text=text
        self.starts=[0]
        for line in text.splitlines(keepends=True): self.starts.append(self.starts[-1]+len(line))
        self.active=None
        self.blocks={}
    def charpos(self):
        line, col=self.getpos()
        return self.starts[line-1]+col
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if tag in ('style','script') and a.get('id'):
            self.active=(tag,a['id'],self.charpos()+len(self.get_starttag_text()))
    def handle_endtag(self, tag):
        if self.active and self.active[0]==tag:
            _,ident,start=self.active
            if ident in self.blocks: raise ValueError(f'Duplicate embedded block: {ident}')
            self.blocks[ident]=(start,self.charpos())
            self.active=None

def main():
    root=Path(__file__).resolve().parents[1]
    page=root/'Workflow_Visual_Comparison.html'
    text=page.read_text(encoding='utf-8')
    def read(f): return (root/f).read_text(encoding='utf-8')
    def data(f): return json.dumps(json.loads(read(f)),ensure_ascii=False).replace('</','<\\/')
    updates={
      'visual-style':read('code/visual.css'),
      'visual-data':data('data/Visual_Summaries.json'),
      'explorer-style':read('code/explorer.css'),
      'explorer-data':data('data/Explorer_Data.json'),
      'explorer-app':read('code/explorer.js'),
      'learning-style':read('code/learning.css'),
      'learning-data':data('data/Learning_Resources.json'),
      'learning-app':read('code/learning.js'),
      'reference-style':read('code/reference.css'),
      'reference-data':data('data/Terminology.json'),
      'reference-app':read('code/reference.js'),
    }
    blocks=Blocks(text);blocks.feed(text)
    if 'download-data' in blocks.blocks:
        a,b=blocks.blocks['download-data']
        archive=json.loads(text[a:b])
        archive['sources']=json.loads(read('data/Explorer_Data.json'))['sources']
        updates['download-data']=json.dumps(archive,ensure_ascii=False).replace('</','<\\/')
    for ident in updates:
        if ident not in blocks.blocks: raise ValueError(f'Missing embedded block: {ident}')
    for ident in sorted(updates,key=lambda x:blocks.blocks[x][0],reverse=True):
        a,b=blocks.blocks[ident];text=text[:a]+updates[ident]+text[b:]
    page.write_text(text,encoding='utf-8')
    print('Updated',page.name)
if __name__=='__main__':main()
