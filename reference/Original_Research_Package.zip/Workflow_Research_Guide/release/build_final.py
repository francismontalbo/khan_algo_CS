"""Build the final reader from the preserved previous edition and edited records.
Run from any directory. Standard library plus beautifulsoup4.
"""
from pathlib import Path
from bs4 import BeautifulSoup
import re, json, shutil, hashlib
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'archive'/'Before_Final_Edition';BASE.mkdir(parents=True,exist_ok=True)
PAGES=['Workflow_Visual_Comparison.html','Algorithm_Applications.html','Algorithm_Simulations.html','Algorithm_Lessons.html','Workflow_Learning_Resources.html','Workflow_Terms_and_Nomenclature.html']
for fn in PAGES:
 if not (BASE/fn).exists():shutil.copyfile(ROOT/fn,BASE/fn)
OLD_TITLE='DAN-Scheduler: Deterministic Three-Stage Co-Optimization of Scheduling, Memory Layout, and Pipeline Overlap for General-Purpose NPUs'
NEW_TITLE='LATTICE: Constraint-Directed Scheduling, Memory Planning, and Pipeline Refinement for NPUs'
AUTHORS='Runhao Liu; Minnan Pei; Fei Ding; Guangzhen Yao; You Li; Peng Xiao; Gang Li; Peng Zhang'
VERSION='arXiv:2607.17422v3, revised 4 August 2026. Version 1 was titled DAN-Scheduler. One evolving preprint, not independent studies.'
ACCESS='Version 3 primary abstract and revision metadata rechecked on 15 October 2026; full v3 text, artifact and hardware results not independently audited.'
URL='https://arxiv.org/abs/2607.17422v3'
def edits(x):
 if isinstance(x,list):return [edits(v) for v in x]
 if isinstance(x,dict):
  y={k:edits(v) for k,v in x.items()}
  if y.get('id')=='E34' and ('title' in y or 'source_id' in y):
   for k in ['title']:y[k]=NEW_TITLE
   for k in ['name','short']:
    if k in y:y[k]='LATTICE'
   for k in ['url','code_url']:
    if k in y:y[k]=URL
   y['authors']=AUTHORS;y['venue']='arXiv:2607.17422v3 (2026), revised 4 August 2026'
   for k in ['version','version_note']:
    if k in y:y[k]=VERSION
   for k in ['access','audit_level','review_status','evidence']:
    if k in y:y[k]=ACCESS
   for k in ['reviewed','refreshed','audit_checked']: 
    if k in y:y[k]='2026-10-15'
   y['evidence_family']='LATTICE (arXiv:2607.17422)'
   y['version_history']=[{'version':'v1','title':OLD_TITLE,'url':'https://arxiv.org/abs/2607.17422v1'},{'version':'v3','title':NEW_TITLE,'url':URL}]
   y['audit_note']='Latest record metadata corrected; the earlier full-text assessment applied to the prior version. Do not transfer detailed v1 results to v3 without checking.'
   if 'mechanism' in y:y['mechanism']='Order commands for memory pressure, construct a memory plan, then refine timing without changing that plan.'
   for k in ['worked','result','strength']:
    if k in y:y[k]='The v3 abstract reports evaluation on six command traces. The reported benefits remain author claims, not reproduced measurements.'
   if 'locator' in y:y['locator']='Version 3 abstract and submission history. Original v1 title retained in version history.'
   if 'sources' in y:y['sources']=[{'title':NEW_TITLE,'url':URL},{'title':'Earlier version: DAN-Scheduler (v1)','url':'https://arxiv.org/abs/2607.17422v1'}]
  return y
 if isinstance(x,str):
  return x.replace(OLD_TITLE,NEW_TITLE).replace('DAN-Scheduler','LATTICE').replace('https://arxiv.org/abs/2607.17422','https://arxiv.org/abs/2607.17422v3') if 'DAN-Scheduler' in x else x
 return x
# Current structured records; originals remain in the earlier packages and snapshot.
for folder in ['data','applications','simulations']:
 for p in (ROOT/folder).glob('*.json'):
  if p.name in ['Audit_Search_Log.json','Audit_Findings.json','Audit_Screening_Log.json']:continue
  if not (BASE/folder/p.name).exists():(BASE/folder).mkdir(exist_ok=True);shutil.copyfile(p,BASE/folder/p.name)
  data=edits(json.loads((BASE/folder/p.name).read_text()))
  p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
terms=json.loads((ROOT/'data/Terminology.json').read_text())
terms['entries'].append({'id':'lattice','term':'LATTICE','full':'LATTICE — the revised name of DAN-Scheduler','brief':'A research compiler pipeline that coordinates command order, memory planning and execution timing.','category':'Concepts','aliases':['LATTICE','DAN-Scheduler'],'explanation':'LATTICE is the title used in version 3 of arXiv:2607.17422. It targets command graphs for neural processing units. The archive does not give an acronym expansion for this name.','here':'A recent contextual study, not an implementation of our fixed-order priority-maintenance experiment.','example':'After placing buffers, it refines timing subject to the chosen memory plan.','caution':'The previous title is a version of the same work, not a separate confirmation. Only v3 abstract and metadata were rechecked in the final edition.','references':[{'label':'LATTICE version 3','url':URL,'record':'E34'},{'label':'DAN-Scheduler version 1','url':'https://arxiv.org/abs/2607.17422v1','record':None}],'related':['dag','xla'],'scope':'Named research system','code':None,'automatic':True,'caseSensitive':True,'codeOnly':False})
(ROOT/'data/Terminology.json').write_text(json.dumps(terms,ensure_ascii=False,indent=2)+'\n')
learn=json.loads((ROOT/'data/Learning_Resources.json').read_text())
learn['term_routes']['lattice']={'title':'LATTICE','full':'LATTICE, formerly DAN-Scheduler','match':'Background only','note':'No dedicated v3 algorithm video was verified. Read the original preprint; these are scheduling prerequisites, not a reproduction.','resources':learn.get('method_routes',{}).get('E34',{}).get('resources',[])[:3],'sources':[{'title':NEW_TITLE,'url':URL}], 'kind':'term'}
learn['counts']['terms']=len(terms['entries']);learn['counts']['resources']=len(learn['resources']);learn['counts']['total']=len(learn['resources'])
(ROOT/'data/Learning_Resources.json').write_text(json.dumps(learn,ensure_ascii=False,indent=2)+'\n')
# Fresh build, without reapplying earlier patch chains.
DATA_MAP={'explorer-data':'data/Explorer_Data.json','visual-data':'data/Visual_Summaries.json','learning-data':'data/Learning_Resources.json','reference-data':'data/Terminology.json','simulation-data':'simulations/data.json','applications-data':'applications/data.json'}
css=(ROOT/'release/final.css').read_text();js=(ROOT/'release/final.js').read_text()
records=json.loads((ROOT/'data/Reviewed_Sources.json').read_text());newsrc=next(s for s in records if s['id']=='E34')
for fn in PAGES:
 s=BeautifulSoup((BASE/fn).read_text(),'html.parser')
 if not s.head or not s.body:
  raw=(BASE/fn).read_text()
  s=BeautifulSoup('<!doctype html><html lang="en"><head></head><body>'+raw+'</body></html>','html.parser')
  if not s.head:s.html.insert(0,s.new_tag('head'))
  if not s.body:s.html.append(s.new_tag('body'))
 for id,path in DATA_MAP.items():
  el=s.find('script',id=id)
  if el:el.string=(ROOT/path).read_text().replace('</','<\\/')
 el=s.find('script',id='download-data')
 if el:
  d=edits(json.loads(el.string));d['sources']=records;el.string=json.dumps(d,ensure_ascii=False).replace('</','<\\/')
 # Update visible original-source metadata and retain the v1 distinction.
 for tag in s.find_all(string=lambda t:t and 'DAN-Scheduler' in t):
  if tag.parent.name not in ('script','style'):tag.replace_with(str(tag).replace(OLD_TITLE,NEW_TITLE).replace('DAN-Scheduler','LATTICE'))
 rec=s.find(id='ref-E34')
 if rec:
  for a in rec.find_all('a',href=True):
   if '2607.17422' in a['href']:a['href']=URL
  for dt in rec.find_all('dt'):
   dd=dt.find_next_sibling('dd')
   if not dd:continue
   key=dt.get_text(' ',strip=True).lower()
   if key=='authors':dd.string=AUTHORS
   elif 'publication' in key:dd.string=VERSION
   elif 'evidence' in key or 'access' in key:dd.string=ACCESS
  version=s.new_tag('p',attrs={'class':'release-version-note'});version.string=ACCESS+' '+VERSION
  rec.select_one('.source-body').insert(0,version)
  rec['data-search']=rec.get('data-search','')+' lattice dan-scheduler version 3'
 # Make final entry point explicit, retain direct-entry utilities and old backlinks.
 if s.title and fn=='Workflow_Visual_Comparison.html':s.title.string='Workflow Algorithm Research Guide | Final edition'
 intro=s.find(id='top')
 if intro and fn=='Workflow_Visual_Comparison.html':
  intro.find('h1').string='Workflow algorithm research guide'
  intro.select_one('.eyebrow').string='BSCS thesis study · CPU experiments · Two semesters'
  intro.select_one('.lead').string='Learn the methods. Compare the evidence. Develop your own improvement.'
  status=intro.select_one('.audit-status')
  if status:
   status.find('strong').string='Final edition · 15 October 2026'
   status.find('span').string='Methods, code and evidence in one guide. Research limits remain visible.'
   status.find('a').string='About this edition';status.find('a')['href']='#edition'
 # Remove misleading old headline in the review status, not underlying cautions.
 review=s.find(id='review-audit')
 if review and review.find('h2'):review.find('h2').string='Evidence and review limits'
 # Main entry defaults to the two foundational selections only for a fresh workspace.
 app=s.find('script',id='explorer-app')
 if app:
  t=app.string or ''
  t=t.replace("selected:['E30','E29',null]","selected:['S1','S3',null]") # IDs checked by release tests.
  t=t.replace("static:['S1','S3','E20']", "static:['S1','S3',null]")
  app.string=t
 # Correct focus and modal keyboard handling in the retained simulation module.
 app=s.find('script',id='simulation-ui')
 if app:
  t=app.string or ''
  t=t.replace("if(!dialog.open||document.querySelector('#app-dialog[open]'))return;", "if(!dialog.open||[...document.querySelectorAll('dialog[open]')].some(d=>d!==dialog&&document.activeElement&&d.contains(document.activeElement)))return;")
  # Highlight the state-changing statement, not its adjacent operation counter.
  helper="function eventCodeIndex(lines,key){let i=lines.findIndex(l=>l.includes('// @'+key));if(i<0)i=lines.findIndex(l=>l.includes(\"emit('\"+key+\"'\"));if(key==='decrement'&&i>0&&/d\\[v\\]--/.test(lines[i-1]))i--;return i;}\n"
  old="function codeLines(e,f){const lines=ENGINE.source(e.id).split('\\n');let active=lines.findIndex(l=>l.includes('// @'+f.key));if(active<0)active=lines.findIndex(l=>l.includes(\"emit('\"+f.key+\"'\"));"
  new=helper+"function codeLines(e,f){const lines=ENGINE.source(e.id).split('\\n');let active=eventCodeIndex(lines,f.key);"
  t=t.replace(old,new)
  old="const raw=ENGINE.source(e.id).split('\\n');let ln=raw.find(l=>l.includes('// @'+f.key))||raw.find(l=>l.includes(\"emit('\"+f.key+\"'\"))||'';"
  t=t.replace(old,"const raw=ENGINE.source(e.id).split('\\n');let ln=raw[eventCodeIndex(raw,f.key)]||'';")
  t=t.replace('Executing now · JavaScript','Code for this step · JavaScript')
  app.string=t
 # Final edition note lives at the end: no new screen or required action.
 main=s.find('main')
 if main and fn=='Workflow_Visual_Comparison.html':
  section=BeautifulSoup('''<section class="chapter release-edition" id="edition" data-no-glossary><p class="step">Edition notes</p><h2>Everything you need to start the study.</h2><p>The literature, connection tree, comparisons, proofs, code, terminology, lessons, simulations and real applications are included. Start with Kahn, then compare the closest competing mechanism.</p><div class="release-grid"><div><h3>Use the guide</h3><p>Learn a method → run an example → compare its assumptions and evidence → write the difference you want to investigate.</p></div><div><h3>Keep your work</h3><p>Use <b>More → Save comparison notes</b> and the proposal notes export. Browser storage is not a backup. Source pages and videos need internet.</p></div><div><h3>Read the evidence labels</h3><p>A software implementation, a paper, and a teaching simulation establish different things. No real Montage speedup or completed novelty review is claimed.</p></div></div><details><summary>What changed in this final edition?</summary><p>Navigation, keyboard controls, screen layouts and exports were checked. Duplicate presentation was reduced. The 2026 preprint record now distinguishes LATTICE v3 from its earlier DAN-Scheduler title. Existing research records, code and examples remain available.</p><p>The literature cutoff is 15 October 2026. Final verification was targeted; it was not another exhaustive literature search or an end-to-end audit of external videos.</p><p><a href="release/Release_Notes.md">Release notes and verification scope</a> · <a href="README.md">Package instructions</a></p></details></section>''','html.parser')
  main.append(section)
 footer=s.find('footer')
 if footer:footer.append(BeautifulSoup('<p class="release-footer" data-no-glossary>Workflow Algorithm Research Guide · Final edition · 15 October 2026</p>','html.parser'))
 # Ensure the preset describes the first comparison accurately.
 preset=s.find(id='comparison-preset')
 if preset:
  opt=preset.find('option',value='static')
  if opt:opt.string='Start here: Kahn and priority selection'
 app=s.find('script',id='applications-ui')
 if app:app.string=(app.string or '').replace("if(dlg.open&&e.key==='Escape')", "if(dlg.open&&e.key==='Escape'&&(!document.activeElement||dlg.contains(document.activeElement)))")
 # Give direct entry pages one main reading landmark without moving dialogs.
 if not s.find('main') and fn!='Audit_Report.html':
  mn=s.new_tag('main',id='standalone-main');s.body.insert(0,mn)
  for child in list(s.body.children):
   if child is mn:continue
   if getattr(child,'name',None) in ['h1','h2','h3','p','section','ul','ol','table']:
    mn.append(child.extract())
 # The printable glossary table must include the newly revised name too.
 if fn=='Workflow_Terms_and_Nomenclature.html':
  section=next((h.parent for h in s.find_all('h2') if h.get_text(strip=True)=='Concepts'),None)
  table=section.find('table') if section else None
  if table and not table.select('[data-term-id="lattice"]'):
   tr=s.new_tag('tr');tr.append(BeautifulSoup('<th><a href="#term-lattice" class="term-link" data-term-id="lattice">LATTICE</a></th><td>LATTICE, formerly DAN-Scheduler</td><td>A revised research compiler pipeline; see version 3 metadata and its earlier title under record E34.</td>','html.parser'))
   (table.tbody or table).append(tr)
 # Correct ordinary cross-links to the final main page within current entry pages.
 for a in s.find_all('a',href=True):
  if a['href']=='Workflow_Visual_Comparison.html':a['href']='Workflow_Research_Guide.html'
  if a.get('target')=='_blank':a['rel']=['noopener','noreferrer']
 if not s.head.find('meta',attrs={'name':'description'}):
  mt=s.new_tag('meta',attrs={'name':'description','content':'A source-backed BSCS research guide to workflow ordering: compare algorithms, inspect proofs and code, and run small teaching simulations.'});s.head.append(mt)
 st=s.new_tag('style',id='final-edition-style');st.string=css;s.head.append(st)
 sc=s.new_tag('script',id='final-edition-app');sc.string=js;s.body.append(sc)
 (ROOT/fn).write_text(str(s),encoding='utf-8')
shutil.copyfile(ROOT/'Workflow_Visual_Comparison.html',ROOT/'Workflow_Research_Guide.html')
print('Built final reader and',len(PAGES)-1,'direct entry pages.')
