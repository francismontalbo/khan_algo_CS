/* Landing-page entry routes. No algorithm or evidence logic is changed. */
(() => {
  'use strict';
  const route = () => {
    const q = new URLSearchParams(window.location.search);
    const view = q.get('open');
    const id = q.get('id');
    if (!view) return;
    try {
      switch (view) {
        case 'lesson':
          if (window.workflowLearning) {
            const lesson = workflowLearning.lessonIds.includes(id) ? id : 'kahn';
            workflowLearning.showLesson(lesson);
          }
          break;
        case 'algorithms': window.workflowLearning?.openAlgorithms(); break;
        case 'simulation': window.workflowSimulation?.open('fifo'); break;
        case 'applications': window.workflowApplications?.open('fifo'); break;
        case 'terms': window.workflowReference?.open(null, 'All'); break;
        case 'videos': window.workflowLearning?.open(); break;
        default: return;
      }
    } catch (error) {
      // Leave the full guide usable if an optional module is unavailable.
      console.warn('The requested section could not be opened. Use the guide menu.', error);
    }
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => requestAnimationFrame(route), {once:true});
  } else requestAnimationFrame(route);
})();