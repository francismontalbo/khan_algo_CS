from pathlib import Path
import json, re
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'archive/Before_Simulations.html'
css=(ROOT/'simulations/simulator.css').read_text()
engine=(ROOT/'simulations/engine.js').read_text()
ui=(ROOT/'simulations/ui.js').read_text()
shell=(ROOT/'simulations/shell.html').read_text()
data=(ROOT/'simulations/data.json').read_text().replace('</','<\\/')
module=(f'<style id="simulation-style">{css}</style>'
        f'<template id="simulation-shell-template">{shell}</template>{shell}'
        f'<script id="simulation-data" type="application/json">{data}</script>'
        f'<script id="simulation-engine">{engine}</script>'
        f'<script id="simulation-ui">{ui}</script>')
h=BASE.read_text()
# Keep the existing interface and all source data. Add one labeled menu item.
h=h.replace('<nav aria-label="Main navigation" class="ux-main-menu">', '<nav aria-label="Main navigation" class="ux-main-menu">')
h=h.replace('<a class="ux-nav-item" data-ui-jump="lineage-tree"', '<button type="button" class="ux-nav-item sim-entry" data-sim-open="fifo" data-icon="play" aria-haspopup="dialog">Simulate</button><a class="ux-nav-item" data-ui-jump="lineage-tree"',1)
# Add the new primary entry without removing the existing CTAs.
pos=h.find('<div class="ux-start-actions"')
if pos>=0:
 end=h.find('</div>',pos)
 h=h[:end]+'<button type="button" class="ux-btn sim-entry" data-sim-open="fifo" data-icon="play" aria-haspopup="dialog">Run a simulation</button>'+h[end:]
# Retain simulations in saved comparison HTML exports.
h=re.sub(r'(<script id="explorer-app"[^>]*>)([\s\S]*?)(</script>)',lambda m:m.group(1)+m.group(2).replace("if(window.workflowReference) content=window.workflowReference.addToExport(content);", "if(window.workflowReference) content=window.workflowReference.addToExport(content);\n if(window.workflowSimulation) content=window.workflowSimulation.addToExport(content);")+m.group(3),h,count=1)
pos=h.rfind('</body>');h=h[:pos]+module+h[pos:]
(ROOT/'Workflow_Visual_Comparison.html').write_text(h)
# Clear standalone entry point, with all simulation data and source locators embedded.
stand='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Algorithm simulations</title><style>body{font:16px/1.6 system-ui;color:#203044;background:#f7f9fc;margin:0;padding:50px 24px}main{max-width:820px;margin:auto}h1{font-size:34px;letter-spacing:-1px}button,a.launch{font:650 15px system-ui;padding:12px 18px;border:1px solid #174eb6;border-radius:8px;color:#fff;background:#174eb6;cursor:pointer}p{max-width:700px}a{color:#174eb6}.lesson-list{display:grid;grid-template-columns:1fr 1fr;gap:10px}.lesson-list button{background:white;color:#264363;text-align:left;font-size:13px;border-color:#b8c6d8}@media(max-width:550px){.lesson-list{grid-template-columns:1fr}}</style></head><body data-sim-standalone="true"><main><p>BSCS thesis research</p><h1>Study one algorithm step at a time.</h1><p>Follow the graph, state, equation and code together. Examples are synthetic and run locally on the CPU.</p><button type="button" data-sim-open="fifo">Start with Kahn’s algorithm</button><p><a href="Workflow_Visual_Comparison.html">Back to the research comparison</a></p><h2>Choose a simulation</h2><div class="lesson-list">'''
D=json.loads((ROOT/'simulations/data.json').read_text())
from html import escape
stand+=''.join(f'<button type="button" data-sim-open="{e["id"]}">{escape(e["name"])}</button>' for e in D['engines'])
stand+='</div><p>Specialist papers link to clearly marked prerequisites or mechanism demonstrations, not invented reproductions.</p></main>'+module+'</body></html>'
(ROOT/'Algorithm_Simulations.html').write_text(stand)
# Add the same module to supplied stand-alone learning pages, without touching research text.
for name in ['Algorithm_Lessons.html','Workflow_Learning_Resources.html']:
    text=(ROOT/'archive'/('Before_Simulations_'+name)).read_text()
    pos=text.rfind('</body>');text=text[:pos]+module+text[pos:]
    (ROOT/name).write_text(text)
print('Built main page and standalone simulator')
