# Reference addition

Added an on-demand terminology panel, hover and focus reminders, click-through explanations, scoped mathematical nomenclature, code-name help, and standalone reference export. Existing content and method choices remain unchanged.

A search ranks exact abbreviations and full forms ahead of incidental mentions. Existing control actions remain intact. Rendered code text and underlying source files are preserved. Exported comparisons retain the embedded glossary.

The automated comparison test now waits for asynchronous notes import before asserting completion; the application import format did not change.
