# Terminology revision

Definitions and UI help added on 15 October 2026. Existing source records, algorithms, proof text, notes schema, comparison presets and layout are preserved.

Abbreviations have full forms. Symbols follow the local teaching model, with explicit scope warnings. Code identifiers point to the retained function or source revision. Code text is not modified; linked spans are added only to the rendered DOM. Ambiguous single letters are not linked in ordinary prose. Existing controls and source links keep their actions. Hover definitions inside controls offer a separate explanation action.

Primary checks for new context definitions include OpenXLA overview and terminology, IBM's AHRSZ publication record, HEFT author publications, Python priority-queue documentation, NetworkX DAG documentation, the author institution's DEWE publication record, and official NASA, IPAC and Dagstuhl terminology. General concepts and local symbols are explanatory definitions, not new experimental findings.

No new literature-review coverage, algorithmic originality or performance gain is claimed.
