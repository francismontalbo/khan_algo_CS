from pathlib import Path
from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup
import json
root=Path(__file__).resolve().parents[1]
assets=root/'assets/ui_update';assets.mkdir(parents=True,exist_ok=True)
results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 context=browser.new_context(viewport={'width':1440,'height':1080},accept_downloads=True)
 page=context.new_page();errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 page.set_content((root/'Workflow_Visual_Comparison.html').read_text(),wait_until='load');page.wait_for_timeout(500)
 page.screenshot(path=str(assets/'01_Desktop.png'))
 results.append({'test':'initial render','errors':errs[:]})
 page.locator('.ux-start-actions [data-open-algorithms]').click();page.wait_for_timeout(80)
 assert page.locator('#learning-dialog').is_visible()
 assert 'Learn the algorithms' in page.locator('#learning-list').inner_text()
 page.screenshot(path=str(assets/'02_Algorithm_Menu.png'))
 page.locator('.algorithm-index-row[data-algorithm-lesson="kahn"]').click();page.wait_for_timeout(80)
 assert 'Kahn' in page.locator('#algorithm-lesson-heading').inner_text()
 page.screenshot(path=str(assets/'03_Lesson.png'))
 results.append({'test':'main lesson call to action and Kahn lesson','passed':True})
 page.locator('#learning-close').click();assert not page.locator('#learning-dialog').is_visible()
 page.locator('.ux-terms').click();assert page.locator('#reference-dialog').is_visible()
 page.locator('#reference-search').fill('XLA');page.wait_for_timeout(150)
 print('TERM_RESULTS',page.locator('#reference-results').inner_text()[:300])
 page.locator('#reference-results .term-select').first.click();assert 'XLA' in page.locator('#term-heading').inner_text()
 page.screenshot(path=str(assets/'04_Term.png'))
 page.locator('#reference-close').click();results.append({'test':'terms to XLA to comparison','passed':True})
 page.locator('.ux-start-actions a').click();page.wait_for_timeout(350)
 page.locator('[data-mode="code"]').click();page.wait_for_timeout(150)
 assert page.locator('[data-mode="code"]').get_attribute('aria-pressed')=='true'
 page.locator('#compare').screenshot(path=str(assets/'05_Code_Comparison.png'),timeout=5000)
 page.locator('[data-mode="summary"]').click()
 page.locator('#compare-table [data-change]').first.click();assert page.locator('#method-picker').is_visible()
 page.locator('#picker-search').fill('Kahn');page.wait_for_timeout(100)
 print('PICKER:',page.locator('#picker-results').inner_text()[:250])
 page.locator('#method-picker [data-close-dialog]').click()
 results.append({'test':'view toggle and method picker','passed':True})
 page.locator('#ui-more summary').click();assert page.locator('#ui-more').get_attribute('open') is not None
 page.screenshot(path=str(assets/'06_More_Menu.png'))
 page.keyboard.press('Escape');assert page.locator('#ui-more').get_attribute('open') is None
 page.locator('#ui-more summary').click();page.locator('#ui-more [data-open-learning]').click();assert page.locator('#learning-dialog').is_visible()
 assert page.locator('#ui-more').get_attribute('open') is None
 page.locator('#learning-close').click()
 page.locator('[data-ui-nav="lineage-tree"]').click();page.wait_for_timeout(350)
 assert page.locator('[data-ui-nav="lineage-tree"]').get_attribute('aria-current')=='location'
 assert page.locator('#tree-viewport').is_visible()
 page.locator('#ui-back-top').click();page.wait_for_timeout(350)
 assert page.evaluate('scrollY')<10
 results.append({'test':'more menu, escape, learning tools, tree and back to top','passed':True})
 print('ERRORS',errs)
 results.append({'test':'no JS errors across desktop flow','passed':not errs,'errors':errs})
 # Mobile views. No reflow of the side-by-side data into cards.
 for width in [390,320,768]:
  pg=context.new_page(viewport={'width':width,'height':844}) if False else context.new_page()
  pg.set_viewport_size({'width':width,'height':844});mobile_errors=[];pg.on('pageerror',lambda e:mobile_errors.append(str(e)))
  pg.set_content((root/'Workflow_Visual_Comparison.html').read_text(),wait_until='load');pg.wait_for_timeout(200)
  overflow=pg.evaluate('({width:innerWidth,doc:document.documentElement.scrollWidth})')
  pg.screenshot(path=str(assets/f'07_Mobile_{width}.png'))
  assert overflow['doc']<=overflow['width']+1,overflow
  pg.locator('.ux-start-actions [data-open-algorithms]').click();pg.locator('.algorithm-index-row[data-algorithm-lesson="kahn"]').click()
  pg.screenshot(path=str(assets/f'08_Mobile_Lesson_{width}.png'))
  pg.locator('#learning-close').click()
  pg.locator('#ui-more summary').click();pg.screenshot(path=str(assets/f'09_Mobile_Menu_{width}.png'))
  pg.locator('#ui-more [data-ui-jump="questions"]').click();pg.wait_for_timeout(100)
  assert pg.locator('#ui-more').get_attribute('open') is None
  results.append({'test':f'viewport {width}px controls and no body overflow','passed':not mobile_errors,'overflow':overflow,'errors':mobile_errors})
  pg.close()
 # Standalone companion remains usable.
 pg=context.new_page();pg.set_content((root/'Algorithm_Lessons.html').read_text(),wait_until='load')
 pg.locator('body > button[data-open-algorithms]').click();pg.locator('.algorithm-index-row[data-algorithm-lesson="kahn"]').click()
 assert pg.locator('#algorithm-lesson-heading').inner_text()=="Kahn’s algorithm"
 results.append({'test':'standalone lesson index and lesson modal','passed':True})
 pg.close();browser.close()
(root/'tests/UI_Interaction_Results.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
