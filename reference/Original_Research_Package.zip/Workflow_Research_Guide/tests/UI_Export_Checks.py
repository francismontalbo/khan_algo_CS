from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parents[1];out=root/'tests/ui_exports';out.mkdir(exist_ok=True)
results=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 c=b.new_context(viewport={'width':1440,'height':1000},accept_downloads=True)
 page=c.new_page();errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 page.set_content((root/'Workflow_Visual_Comparison.html').read_text(),wait_until='load')
 page.locator('#export-comparison').scroll_into_view_if_needed()
 with page.expect_download() as download:page.locator('#export-comparison').click()
 path=out/'Saved_Comparison.html';download.value.save_as(path)
 pg=c.new_page();export_errors=[];pg.on('pageerror',lambda e:export_errors.append(str(e)))
 pg.set_content(path.read_text(),wait_until='load')
 assert pg.locator('#compare-table').is_visible();assert not export_errors,export_errors
 assert '--action:#174eb6' in path.read_text()
 results.append({'test':'saved comparison retains UI styles, glossary and lessons','passed':True,'errors':export_errors})
 pg.close()
 page.locator('.ux-main-menu [data-open-algorithms]').click();page.locator('#learning-save').click() if False else None
 with page.expect_download() as d:page.locator('#learning-save').click()
 path=out/'Saved_Learning_Resources.html';d.value.save_as(path)
 pg=c.new_page();e2=[];pg.on('pageerror',lambda e:e2.append(str(e)))
 pg.set_content(path.read_text(),wait_until='load')
 pg.locator('body > button[data-open-algorithms]').click();pg.locator('.algorithm-index-row[data-algorithm-lesson="kahn"]').click()
 assert not e2,e2
 assert '--action:#174eb6' in path.read_text()
 results.append({'test':'saved resources retain algorithm navigation and button styling','passed':True,'errors':e2});pg.close()
 page.locator('#learning-close').click()
 page.locator('.ux-main-menu [data-open-algorithms]').focus()
 page.keyboard.press('Enter');assert page.locator('#learning-dialog').is_visible();page.keyboard.press('Escape');assert not page.locator('#learning-dialog').is_visible()
 page.locator('#ui-more summary').focus();page.keyboard.press('Enter');assert page.locator('#ui-more').get_attribute('open') is not None
 page.keyboard.press('Escape');assert page.locator('#ui-more').get_attribute('open') is None
 computed=page.locator('#ui-more summary').evaluate('el=>({outline:getComputedStyle(el).outlineWidth,style:getComputedStyle(el).outlineStyle,height:el.getBoundingClientRect().height})')
 assert computed['outline']=='3px',computed
 results.append({'test':'keyboard opens, escapes and visible focus','passed':True,'focus_style':computed})
 targets=page.locator('.ux-header :is(button,a,summary), .ux-start-actions :is(a,button)').evaluate_all('(es)=>es.filter(e=>e.offsetHeight).map(e=>({text:e.innerText.replace(/\\s+/g," "),height:Math.round(e.getBoundingClientRect().height)}))')
 results.append({'test':'navigation target sizes','measured':targets})
 assert not errs,errs
 b.close()
(root/'tests/UI_Exports_and_Keyboard.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
