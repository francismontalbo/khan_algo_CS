# Algorithm learning addition — 15 October 2026

## Coverage

Ten optional lessons connect the graph representation, Kahn, DFS, heap priorities, BFS reachability, DAG longest paths, file-use counters, edge insertion, invariants and complete-cost measurement. Each lesson includes its role, short algorithm steps, a mathematical statement, correctness reasoning, applicable cost, a worked example, source links and one open research question. The original video recordings are neither edited nor narrated over.

NPTEL course identity and instructor were checked at https://nptel.ac.in/courses/106106131. The official VTU course page at https://online.vtu.ac.in/v1/course-details/Design-and-Analysis-of-Algorithms links the named graph representation, topological sort, heap-update, DAG-longest-path and algorithm-checking recordings. Catalog durations are not independently measured. The heap-update iframe contains an encoded trailing time parameter; only the eleven-character video identifier was retained. No time cues are invented.

MIT OpenCourseWare pages directly describe DFS with topological sorting and cycle detection, BFS, and binary heaps. Their retained publisher links and descriptions were reopened for topic fit. Python graphlib and heapq, and NetworkX transitive reduction and lexicographical topological sorting, provide the written definitions. The tagged XLA source is retained from the previous audit; it is not newly executed here. See per-record evidence URLs and check locations in data/Learning_Resources.json.

## Evidence boundaries

Videos were not watched end to end, external streams did not play during testing, and regional availability was not confirmed. Publisher-linked video IDs and local player controls were checked. No dedicated XLA or Pearce–Kelly algorithm recording is represented as verified. Their prerequisite videos are labeled, and original sources remain the authority. The edge-insertion teaching baseline is explicitly not Pearce–Kelly. DAG critical paths are explicitly not HEFT. The fixed-score priority example is not a dynamic-priority implementation.

## Code verification

Code_Checks.json records 64 exhaustive forward-edge four-vertex DAGs, 1,024 insertion checks, 400 randomized labeled DAGs (0 to 18 vertices) and five negative checks. Reference oracles include independent permutation checking, a boolean reachability closure, exhaustive path accumulation, explicit ready-set score selection and Python graphlib. These are finite tests, not a formal proof certificate, performance experiment or novelty audit.

The one-file counter example deliberately stores a trace of remaining sets. Its stated tracing complexity is not the cost of an optimized counter update. All code shown in lesson panels is independently written and marked as teaching code.

## Interface verification

The main page rendered all ten lessons, all 67 method-learning routes and all 63 resource details with no captured JavaScript error. Checked video URL selection and player removal on lesson change, preservation of comparator selection after returning, download of the Python module, three standalone exports, and a saved comparison export. Mobile width 390 pixels was checked for Kahn, counting and reachability, including horizontal-overflow detection. Desktop and narrow screenshots were inspected. External network was blocked during these checks. No exhaustive browser-platform certification is claimed.

The following files match the supplied audited package byte for byte: data/Explorer_Data.json; data/Reviewed_Sources.json; data/Original_Lineage.json; data/Terminology.json; code/workflow_methods.py; code/run_checks.py. Research claims, prior-source limitations and earlier proof examples remain unchanged.
