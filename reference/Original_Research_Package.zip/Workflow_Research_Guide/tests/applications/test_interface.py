from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path(__file__).resolve().parents[2]
shots=ROOT/'assets/applications';shots.mkdir(exist_ok=True)
results=[];errors=[]
def check(name,ok):
 results.append({'check':name,'pass':bool(ok)})
 if not ok:print('FAIL',name)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1050})
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((ROOT/'Workflow_Visual_Comparison.html').read_text(),wait_until='domcontentloaded');page.wait_for_timeout(1300)
 check('Applications module starts',page.evaluate('!!window.workflowApplications'))
 check('All 23 profiles loaded',page.evaluate('workflowApplications.data.profiles.length')==23)
 check('All 58 research mappings loaded',page.evaluate('Object.keys(workflowApplications.data.routes).length')==58)
 check('Contextual application buttons',page.locator('[data-app-method]').count()>2)
 check('Source comparison block',page.locator('#app-compare-panel').count()==1)
 page.screenshot(path=str(shots/'01_Comparison_Applications.png'))
 page.locator('.ux-start-actions [data-app-open="fifo"]').click();page.wait_for_timeout(200)
 check('Kahn real-use detail opens',page.locator('#app-dialog').is_visible() and 'Django' in page.locator('#app-main').inner_text())
 page.screenshot(path=str(shots/'02_Kahn_Real_Use.png'))
 page.locator('#app-main [data-app-run]').click();page.wait_for_timeout(200)
 check('Kahn example launches simulator',page.evaluate("workflowSimulation.getState().example==='app-web'"))
 page.locator('#sim-last').click();
 check('Kahn noConflict output present','noConflict' in page.locator('#sim-runs').inner_text())
 page.screenshot(path=str(shots/'03_Website_Script_Simulation.png'))
 page.locator('[data-app-evidence="fifo"]').click();page.wait_for_timeout(100)
 page.keyboard.press('Escape')
 check('Escape closes only application overlay',not page.locator('#app-dialog').is_visible() and page.locator('#sim-dialog').is_visible())
 page.locator('#sim-close').click()
 # Each algorithm application launches and runs to completion; each source has its evidence link.
 for p in page.evaluate('workflowApplications.data.profiles'):
  page.evaluate('(id)=>workflowApplications.open(id)',p['id'])
  check('Application details: '+p['id'],page.locator('#app-main .app-source').count()==len(p['refs']))
  page.locator('#app-main [data-app-run]').click()
  page.locator('#sim-last').click()
  check('Named scenario runs: '+p['id'],page.evaluate('(id)=>workflowSimulation.getState().id===id',p['id']) and not page.locator('#sim-error').is_visible())
  page.locator('#sim-close').click()
 # All research mapping contexts render without claiming prerequisite deployment.
 for id in page.evaluate('Object.keys(workflowApplications.data.routes)'):
  page.evaluate('(id)=>workflowApplications.open(workflowApplications.data.routes[id].engine,id)',id)
  check('Research context: '+id,page.locator('.app-route').count()==1 and len(page.locator('.app-route').inner_text())>80)
  page.locator('#app-close').click()
 # Search and sources.
 page.evaluate("workflowApplications.open('pk','D4')")
 page.locator('#app-search').fill('database');check('Application search works',page.locator('#app-list button').count()==1)
 page.locator('#app-search').fill('')
 page.locator('#app-main .app-source summary').first.click()
 check('Source locator can be inspected','File introduction' in page.locator('#app-main').inner_text())
 page.screenshot(path=str(shots/'04_Pearce_Kelly_Application.png'))
 page.locator('#app-close').click()
 # Save comparison export and reopen it offline.
 with page.expect_download() as dl:
  page.locator('#export-comparison').click()
 path=ROOT/'tests/applications/Saved_Comparison.html';dl.value.save_as(path)
 text=path.read_text();check('Saved comparison retains application records','id="applications-data"' in text)
 ep=browser.new_page();ep.on('pageerror',lambda e:errors.append('export: '+str(e)))
 ep.set_content(text,wait_until='domcontentloaded');ep.wait_for_timeout(500)
 check('Exported application module opens',ep.evaluate('!!window.workflowApplications'))
 ep.evaluate("workflowApplications.open('dfs')");check('Exported application details', 'Django migrations' in ep.locator('#app-main').inner_text());ep.close()
 # Standalone page and mobile layouts.
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.on('pageerror',lambda e:errors.append('mobile: '+str(e)))
 page.set_content((ROOT/'Algorithm_Applications.html').read_text(),wait_until='domcontentloaded');page.wait_for_timeout(500)
 check('Standalone applications open on mobile',page.locator('#app-dialog').is_visible())
 check('Mobile selector visible',page.locator('#app-mobile-select').is_visible())
 check('Mobile application has no horizontal overflow',page.evaluate("document.querySelector('#app-main').scrollWidth <= document.querySelector('#app-main').clientWidth+1"))
 page.screenshot(path=str(shots/'05_Mobile_Application.png'))
 page.locator('#app-mobile-select').select_option('dfs');check('Mobile algorithm switch', 'Django migrations' in page.locator('#app-main').inner_text())
 page.locator('#app-main [data-app-run]').click();page.wait_for_timeout(200);page.screenshot(path=str(shots/'06_Mobile_Migration_Simulation.png'))
 check('Mobile named simulation opens',page.evaluate("workflowSimulation.getState().example==='app-db'"))
 page.locator('#sim-close').click()
 # Existing guide itself remains usable on mobile.
 page.close()
 page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 page.on('pageerror',lambda e:errors.append('mobile main: '+str(e)))
 page.set_content((ROOT/'Workflow_Visual_Comparison.html').read_text(),wait_until='domcontentloaded');page.wait_for_timeout(600)
 check('Main page mobile no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
 page.locator('.ux-start-actions [data-app-open="fifo"]').click();check('Mobile main launch',page.locator('#app-dialog').is_visible())
 browser.close()
check('No JavaScript errors',not errors)
report={'checks':len(results),'passed':sum(x['pass'] for x in results),'errors':errors,'details':results,'environment':'Chromium headless; file contents loaded locally; no external media playback tested.'}
(ROOT/'tests/applications/Interface_Results.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='details'},indent=2))
assert report['checks']==report['passed'], 'UI checks failed'
