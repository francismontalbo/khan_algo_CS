"""Exercise new lessons plus preserved shared learning and comparison paths."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib,shutil
R=Path(__file__).resolve().parents[1]
S=R/'tests/algorithm_lessons';S.mkdir(exist_ok=True)
html=(R/'Workflow_Visual_Comparison.html').read_text();D=json.loads((R/'data/Learning_Resources.json').read_text())
err=[];external=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'],headless=True)
    page=browser.new_page(viewport={'width':1440,'height':1050},accept_downloads=True)
    page.set_default_timeout(7000)
    page.on('pageerror',lambda e:err.append(str(e)))
    page.on('request',lambda r:external.append(r.url) if r.url.startswith('http') else None)
    # Network disabled during checks; validates local UI, not external playback.
    page.route('https://**',lambda route:route.abort())
    page.set_content(html,wait_until='domcontentloaded')
    page.wait_for_function('window.workflowLearning?.showLesson && window.workflowExplorer')
    original=page.evaluate('workflowExplorer.getState()')
    page.locator('[data-open-learning]').first.click()
    assert page.locator('.algorithm-banner').is_visible()
    page.locator('[data-open-algorithms]').first.click()
    assert page.locator('.algorithm-index-row').count()==10
    page.screenshot(path=str(S/'01_Lesson_List.png'))
    page.locator('[data-algorithm-lesson="kahn"]').click()
    assert page.locator('#algorithm-lesson-heading').inner_text()=='Kahn’s algorithm'
    assert page.locator('.algorithm-code pre').inner_text().find('def kahn')>=0
    page.screenshot(path=str(S/'02_Kahn_Video_and_Code.png'))
    # Each lesson, source link, neighbor navigation and metadata renders.
    for l in D['algorithm_lessons']:
        page.evaluate('(id)=>workflowLearning.showLesson(id)',l['id'])
        assert page.locator('#algorithm-lesson-heading').inner_text()==l['title']
        assert page.locator('.algorithm-question').is_visible()
        assert page.locator('.algorithm-next').count()==1
        assert page.locator('.algorithm-warning').inner_text().find(l['warning'])>=0
        assert page.locator('.algorithm-sources a').count()==len(l['references'])
        if l['code']:assert page.locator('.algorithm-code pre').inner_text()==l['code']
    assert external==[],external
    print('PASS lesson displays',flush=True)
    # Dynamic player URL selection is local-checked, not a successful stream.
    page.evaluate('workflowLearning.showLesson("kahn")')
    page.locator('[data-algorithm-play]').click()
    assert '_9a95v2shgQ' in page.locator('#algorithm-player iframe').get_attribute('src')
    page.locator('.algorithm-next [data-algorithm-lesson]').last.click()
    assert page.locator('#algorithm-lesson-heading').inner_text()=='DFS ordering and cycle detection'
    assert page.locator('iframe').count()==0
    page.keyboard.press('Escape')
    assert page.evaluate('workflowExplorer.getState()')==original
    print('PASS player and comparison return',flush=True)
    # Every method still opens, and every route has an algorithm primer.
    for k,r in D['method_routes'].items():
        page.evaluate('(id)=>workflowLearning.open("method",id)',k)
        assert page.locator('.algorithm-inline button').count()>0
        assert page.locator('.learning-context-sources').count()==1
    page.keyboard.press('Escape')
    print('PASS method routes',flush=True)
    # Existing external resource views remain available.
    for r in D['resources']:
        page.evaluate('(id)=>workflowLearning.showResource(id)',r['id'])
        assert page.locator('#learning-resource-heading').inner_text()==r['title']
    page.keyboard.press('Escape')
    print('PASS resource screens',flush=True)
    # Generate standalone files from the actual embedded runtime, including all support.
    (R/'Algorithm_Lessons.html').write_text(page.evaluate('workflowLearning.algorithmStandalone()'))
    (R/'Workflow_Learning_Resources.html').write_text(page.evaluate('workflowLearning.standalone()'))
    (R/'Workflow_Terms_and_Nomenclature.html').write_text(page.evaluate('workflowReference.referenceFile()'))
    page.evaluate('workflowLearning.showLesson("counting")')
    page.screenshot(path=str(S/'03_XLA_Algorithm_Reading.png'))
    with page.expect_download() as dl:
        page.locator('[data-algorithm-download]').click()
    dl.value.save_as(S/'Downloaded_Algorithm_Module.py')
    assert (S/'Downloaded_Algorithm_Module.py').read_text()==(R/'code/algorithm_foundations.py').read_text()
    print('PASS code export',flush=True)
    # Standalone resource and export integration.
    for name in ['Algorithm_Lessons.html','Workflow_Learning_Resources.html','Workflow_Terms_and_Nomenclature.html']:
        q=browser.new_page(viewport={'width':1200,'height':900})
        q.on('pageerror',lambda e:err.append(str(e)))
        q.set_content((R/name).read_text(),wait_until='domcontentloaded')
        q.wait_for_function('!!window.workflowLearning?.showLesson')
        q.evaluate('workflowLearning.showLesson("priority")')
        assert q.locator('.algorithm-code').is_visible()
        q.close()
    print('PASS standalone pages',flush=True)
    # Mobile view must remain readable without page-level overflow.
    page.keyboard.press('Escape')
    page.set_viewport_size({'width':390,'height':844})
    for id in ['kahn','counting','reachability']:
        page.evaluate('(id)=>workflowLearning.showLesson(id)',id)
        assert page.evaluate('document.getElementById("learning-scroll").scrollWidth <= document.getElementById("learning-scroll").clientWidth + 2')
        if id=='kahn':page.screenshot(path=str(S/'04_Mobile_Kahn.png'))
    print('PASS mobile',flush=True)
    # Capture the actual code next to the computed trace.
    page.set_viewport_size({'width':1440,'height':1050})
    page.evaluate('workflowLearning.showLesson("kahn")')
    page.locator('.algorithm-lower').scroll_into_view_if_needed()
    page.screenshot(path=str(S/'05_Code_and_Worked_Example.png'))
    # Comparison state and math/code views still work after closing.
    page.keyboard.press('Escape');page.set_viewport_size({'width':1440,'height':1050})
    page.evaluate('workflowExplorer.setView("code")')
    assert page.locator('#compare-table').count()==1
    assert not err,err
    browser.close()
original_root=Path('/mnt/data/work/Workflow_Comparison_Audited')
keep=['data/Explorer_Data.json','data/Reviewed_Sources.json','data/Original_Lineage.json','data/Terminology.json','code/workflow_methods.py','code/run_checks.py']
for name in keep:assert (R/name).read_bytes()==(original_root/name).read_bytes(),name
out={'checked_date':'2026-10-15','algorithm_lessons_rendered':10,'method_learning_routes_rendered':len(D['method_routes']),'resource_details_rendered':len(D['resources']),'standalone_exports_tested':3,'mobile_views_checked':3,'source_and_research_code_preserved':keep,'no_initial_external_requests':True,'javascript_errors':err,'playback':'Not verified; external network blocked during UI tests. Only the selected embed URL and local controls were checked.'}
(S/'Interface_Checks.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
