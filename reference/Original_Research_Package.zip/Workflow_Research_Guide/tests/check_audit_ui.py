"""Final repaired-page checks. Network and scientific replication are separately scoped."""
from pathlib import Path
import json, shutil, hashlib
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];P=R/'Workflow_Visual_Comparison.html';H=P.read_text();D=json.loads((R/'data/Explorer_Data.json').read_text());out=R/'tests/current_audit';out.mkdir(exist_ok=True)
results={'date':'2026-10-15','scope':'Final-state Chromium injected-HTML checks, not all possible comparison combinations. No external-video playback or Safari verification.'}
soup=BeautifulSoup(H,'html.parser');ids=[n['id'] for n in soup.select('[id]')]
assert len(ids)==len(set(ids));missing=[]
for a in soup.select('a[href^="#"]'):
 h=a['href'][1:]
 if h and h not in ids:missing.append(h)
assert not missing,missing
assert json.loads(soup.find(id='explorer-data').string)==D
assert len(soup.select('.source-record'))==len(D['sources'])==36
assert '29 external records' not in soup.get_text()
assert soup.find(id='audit-search-record').get_text().count('Q01')==1
assert len(D['methods'])==66
assert all(s.get('audit_level') and s.get('evidence_family') for s in D['sources'])
assert all('See primary source for the complete author list.' not in s['authors'] for s in D['sources'])
assert json.loads(soup.find(id='download-data').string)['sources']==D['sources']
results['static_ids_anchors_and_embedded_data']='Pass'
# All pre-existing source-code excerpts must be unchanged.
old=json.loads((R/'archive/Before_15_October_Explorer_Data.json').read_text())
now={m['id']:m for m in D['methods']}
assert all(m.get('code','')==now[m['id']].get('code','') for m in old['methods'])
assert hashlib.sha256((R/'code/workflow_methods.py').read_bytes()).hexdigest()==hashlib.sha256((R/'archive/Before_15_October_workflow_methods.py').read_bytes()).hexdigest()
results['algorithm_code_and_original_excerpts_unchanged']=True
errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':1000});page.on('pageerror',lambda e:errors.append(str(e)));page.set_default_timeout(5000)
 page.set_content(H,wait_until='domcontentloaded');page.wait_for_function('window.workflowExplorer && window.workflowLearning && window.workflowReference')
 page.screenshot(path=str(out/'01_main.png'))
 # Render every selectable record through shared full-specification and source-preview paths.
 page.evaluate('workflowExplorer.setView("all")')
 for m in D['methods']:
  if m.get('branch'):continue
  page.evaluate('(id)=>workflowExplorer.chooseMethod(0,id)',m['id'])
  text=page.locator('#compare-table').inner_text()
  assert m['name'] in text,m['id']
  assert 'Audit status' in text,m['id']
  assert 'undefined' not in text,m['id']
  page.evaluate('(id)=>workflowExplorer.showSource(id)',m['id'])
  assert page.locator('#source-peek').is_visible()
  page.keyboard.press('Escape')
 results['selectable_records_full_specs_and_preview_checked']=58
 # New audit preset, lineage locations, full source return, source filters.
 page.locator('#comparison-preset').select_option('audit');page.locator('#compare-mode [data-mode="all"]').click()
 assert 'Horizons' in page.locator('#compare-table').inner_text()
 assert 'shared' in page.locator('#compare-table').inner_text().lower()
 page.locator('#compare').scroll_into_view_if_needed();page.screenshot(path=str(out/'02_audit_comparison.png'))
 for sid in ['E31','E32','E33','E34','E35','E36']:
  page.evaluate('(id)=>workflowExplorer.selectNode(id,true)',sid)
  assert page.locator('#tree-stage [data-tree-node="'+sid+'"]') .count()==1
  page.evaluate('(id)=>{const e=document.getElementById("ref-"+id);e.open=true;e.scrollIntoView();}',sid)
  assert page.locator('#ref-'+sid).is_visible()
 page.locator('#source-search').fill('Horizons');assert '1 of 36' in page.locator('#source-count').inner_text();page.locator('#source-search').fill('')
 page.locator('.quicknav a[href="#review-audit"]').click()
 page.screenshot(path=str(out/'03_audit_status.png'))
 page.locator('#review-audit summary').first.click();assert page.locator('#audit-search-record').is_visible()
 assert 'Wohlin' in page.locator('#ref-E36').inner_text() or 'Wohlin' in page.locator('#ref-E36').text_content()
 page.screenshot(path=str(out/'04_selection_log.png'))
 page.locator('[data-download="sources"]').evaluate("el=>{for(let n=el.parentElement;n;n=n.parentElement){if(n.tagName==='DETAILS')n.open=true;}}")
 with page.expect_download() as downloaded_sources:page.locator('[data-download="sources"]').click()
 source_export=out/'Reviewed_Sources_Export.json';downloaded_sources.value.save_as(str(source_export));assert json.loads(source_export.read_text())==D['sources']
 results['new_records_search_tree_and_audit_record']='Pass'
 results['source_export_matches_all_36_records']=True
 # Export must keep audits at the exact same place as the compared evidence.
 page.locator('#comparison-preset').select_option('audit');page.locator('#compare-mode [data-mode="all"]').click()
 with page.expect_download() as download:page.locator('#export-comparison').click()
 export=out/'Audit_Comparison_Export.html';download.value.save_as(str(export));eh=export.read_text();assert 'Evidence family' in eh and 'Audit status' in eh
 e=b.new_page();e.on('pageerror',lambda x:errors.append(str(x)));e.set_content(eh,wait_until='domcontentloaded');assert 'Audit status' in e.locator('body').inner_text();e.close()
 results['saved_comparison_retains_evidence_status']=True
 # Save the final standalone modules, using their normal export functions.
 (R/'Workflow_Terms_and_Nomenclature.html').write_text(page.evaluate('workflowReference.referenceFile()'))
 (R/'Workflow_Learning_Resources.html').write_text(page.evaluate('workflowLearning.standalone()'))
 mo=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);mo.on('pageerror',lambda e:errors.append(str(e)))
 mo.set_content(H,wait_until='domcontentloaded');mo.wait_for_function('window.workflowExplorer')
 assert mo.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
 mo.locator('.quicknav a[href="#review-audit"]').tap();mo.screenshot(path=str(out/'05_mobile_audit.png'))
 assert mo.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
 mo.locator('#review-audit summary').first.tap();assert mo.locator('#audit-search-record').is_visible()
 assert mo.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
 mo.screenshot(path=str(out/'06_mobile_search.png'))
 results['mobile_main_audit_and_expanded_search_no_page_overflow']=True
 b.close()
assert not errors,errors;results['console_errors']=errors
results['synthetic_suite']=json.loads((R/'results/checks.json').read_text())['all_ready_scores_and_orders_equal']
(out/'Final_Page_Checks.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
