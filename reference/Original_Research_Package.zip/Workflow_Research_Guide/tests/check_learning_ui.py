"""Local interface, coverage and preservation checks. External playback is not tested."""
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
import json,shutil,hashlib,re
R=Path(__file__).resolve().parents[1]
HTML=(R/'Workflow_Visual_Comparison.html').read_text()
L=json.loads((R/'data/Learning_Resources.json').read_text());T=json.loads((R/'data/Terminology.json').read_text());D=json.loads((R/'data/Explorer_Data.json').read_text())
results={'checked_date':'2026-10-15'};errors=[];requests=[]
ids={r['id'] for r in L['resources']}
assert len(ids)==len(L['resources'])
assert {t['id'] for t in T['entries']}==set(L['term_routes'])
assert {m['id'] for m in D['methods']}<=set(L['method_routes'])
for routes in ['term_routes','method_routes','source_routes']:
 for key,r in L[routes].items():
  assert set(r['resources'])<=ids
  assert r['note'] and r['match']
for r in L['resources']:
 assert r['url'].startswith('https://') and r['evidence_url']==r['url']
 assert r['checked']=='2026-10-15' and r['focus'] and r['limit'] and r['verification']
 assert not r['youtube_id'] or re.fullmatch(r'[A-Za-z0-9_-]{11}',r['youtube_id'])
results['catalog_and_complete_coverage']=L['counts']
soup=BeautifulSoup(HTML,'html.parser')
assert not soup.select('script[src], iframe')
for id in ['learning-data','learning-app','learning-style','learning-dialog']:assert len(soup.select('#'+id))==1
results['no_initial_video_embed_or_remote_script']=True
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'],headless=True)
 page=browser.new_page(viewport={'width':1440,'height':1000})
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('request',lambda r: requests.append(r.url))
 page.set_default_timeout(5000)
 # The environment blocks file-origin navigation; inject identical standalone HTML for UI checks.
 page.set_content(HTML,wait_until='domcontentloaded')
 page.wait_for_function('window.workflowLearning && window.workflowReference && window.workflowExplorer')
 initial=page.evaluate('workflowExplorer.getState()');pos=page.evaluate('({x:scrollX,y:scrollY})')
 page.locator('#compare-table thead [data-learning-method]').first.click()
 assert page.locator('#learning-list').inner_text().find('No dedicated walkthrough')>=0
 page.locator('#learning-list [data-learning-resource="d-xla"]').click()
 assert page.locator('#learning-detail .learning-actions a').get_attribute('href')=='https://openxla.org/xla'
 page.keyboard.press('Escape')
 assert initial==page.evaluate('workflowExplorer.getState()')
 assert pos==page.evaluate('({x:scrollX,y:scrollY})')
 results['comparison_context_and_selection_preserved']=True
 print('pass: comparison context',flush=True)
 # Every term has a deliberate route, not a guessed tutorial of a paper.
 for e in T['entries']:
  page.evaluate('(id)=>workflowReference.openTerm(id)',e['id'])
  assert page.locator('.term-learning h4').inner_text()=='Watch or read'
  if not L['term_routes'][e['id']]['resources']:assert 'No dedicated tutorial verified' in page.locator('.term-learning').inner_text()
 page.locator('#reference-close').click()
 results['definition_learning_sections_checked']=len(T['entries'])
 # Every method learning view renders its source context without errors.
 for m in D['methods']:
  page.evaluate('(id)=>workflowLearning.open("method",id)',m['id'])
  assert page.locator('#learning-list .learning-context h3').inner_text()==m['name']
  assert page.locator('#learning-list .learning-context-sources').count()==1
 page.keyboard.press('Escape')
 results['method_learning_views_checked']=len(D['methods'])
 # Nested modals restore the term and source screens without changing their state.
 page.evaluate('workflowExplorer.showSource("E20")')
 page.evaluate('workflowReference.openTerm("xla")')
 page.locator('.term-learning [data-learning-resource="v-stablehlo"]').click()
 assert page.locator('#learning-resource-heading').inner_text()=='StableHLO Composites'
 page.screenshot(path=str(R/'assets/Learning_Video.png'))
 page.keyboard.press('Escape');assert page.locator('#reference-dialog').is_visible()
 assert page.locator('#term-heading').inner_text()=='XLA'
 page.keyboard.press('Escape');assert page.locator('#source-peek').is_visible()
 page.keyboard.press('Escape');assert not page.locator('#source-peek').is_visible()
 results['nested_dialogs_escape_and_return']=True
 print('pass: complete routes and nested return',flush=True)
 # Filter, search suggestions and one checked official-link card for every item.
 page.locator('.quicknav [data-open-learning]').click()
 assert page.locator('#learning-list .learning-card').count()==6
 page.locator('#learning-all').click();assert page.locator('#learning-list .learning-card').count()==L['counts']['resources']
 page.locator('[data-learn-format="Video"]').click();assert page.locator('#learning-list .learning-card').count()==22
 page.locator('#learning-search').fill('XLA')
 assert page.locator('#learning-list [data-learning-term="xla"]').count()>=1
 page.locator('#learning-list [data-learning-term="xla"]').first.click()
 assert page.locator('#learning-list .learning-context h3').inner_text()=='XLA'
 page.locator('#learning-search').fill('heap')
 assert page.locator('#learning-list [data-learning-term="heap"]').count()>=1
 page.locator('#learning-list [data-learning-term="heap"]').first.click()
 assert page.locator('#learning-list .learning-card').count()==2
 for r in L['resources']:
  page.evaluate('(id)=>workflowLearning.showResource(id)',r['id'])
  assert page.locator('#learning-resource-heading').inner_text()==r['title']
  assert page.locator('#learning-detail .learning-actions a').get_attribute('href')==r['url']
  assert r['limit'] in page.locator('#learning-detail').inner_text()
  assert page.locator('#learning-detail iframe').count()==0
 results['all_resource_details_filters_and_global_search']=True
 # Block any remote request during player test. Verify user consent, source, no autoplay, stop on close.
 assert not [u for u in requests if u.startswith('https://')],requests
 page.route('https://**/*',lambda route:route.abort())
 page.evaluate('workflowLearning.open("term","dag")')
 page.locator('#learning-list [data-learning-resource="v-dag"]').click()
 assert page.locator('#learning-detail iframe').count()==0
 page.locator('[data-learning-play="v-dag"]').click()
 frame=page.locator('#learning-player iframe')
 assert 'youtube-nocookie.com/embed/E33i67e_X9Q?rel=0' in frame.get_attribute('src')
 assert 'autoplay' not in frame.get_attribute('src')
 assert frame.get_attribute('title')
 page.keyboard.press('Escape');assert page.locator('#learning-detail iframe').count()==0
 results['no_automatic_network_user_loaded_player_stops_on_close']=True
 print('pass: learning cards and privacy',flush=True)
 # Existing export paths retain the new module; original code text untouched.
 page.locator('#comparison-preset').select_option('versions')
 page.locator('#compare-mode [data-mode="code"]').click()
 with page.expect_download() as d:page.locator('#export-comparison').click()
 out=R/'tests/Learning_Export_Test.html';d.value.save_as(str(out))
 ex=browser.new_page();ex.on('pageerror',lambda e:errors.append(str(e)))
 ex.set_content(out.read_text(),wait_until='domcontentloaded');ex.wait_for_function('window.workflowLearning && window.workflowReference')
 ex.evaluate('workflowReference.openTerm("xla")');ex.locator('.term-learning [data-learning-resource="d-xla"]').click()
 assert ex.locator('#learning-resource-heading').inner_text()=='XLA overview';ex.close()
 (R/'Workflow_Terms_and_Nomenclature.html').write_text(page.evaluate('workflowReference.referenceFile()'))
 (R/'Workflow_Learning_Resources.html').write_text(page.evaluate('workflowLearning.standalone()'))
 for fn in ['Workflow_Terms_and_Nomenclature.html','Workflow_Learning_Resources.html']:
  tab=browser.new_page();tab.on('pageerror',lambda e:errors.append(str(e)))
  tab.set_content((R/fn).read_text(),wait_until='domcontentloaded');tab.wait_for_function('window.workflowLearning')
  tab.evaluate('workflowLearning.open("term","xla")');assert tab.locator('#learning-list .learning-card').count()==4
  tab.close()
 results['comparison_glossary_and_learning_exports_are_self_contained']=True
 # Narrow-screen UX and click, no horizontal page overflow.
 mobile=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=1)
 mobile.on('pageerror',lambda e:errors.append(str(e)))
 mobile.set_content(HTML,wait_until='domcontentloaded')
 mobile.wait_for_function('window.workflowLearning')
 mobile.evaluate('workflowReference.openTerm("xla")')
 mobile.locator('.term-learning [data-learning-term="xla"]').tap()
 assert mobile.locator('#learning-scroll').evaluate('(e)=>e.scrollWidth<=e.clientWidth+1')
 assert mobile.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
 mobile.wait_for_timeout(350)
 mobile.screenshot(path=str(R/'assets/Learning_Mobile.png'))
 mobile.locator('#learning-list [data-learning-resource="v-stablehlo"]').tap()
 assert mobile.locator('#learning-scroll').evaluate('(e)=>e.scrollWidth<=e.clientWidth+1')
 mobile.wait_for_timeout(350)
 mobile.screenshot(path=str(R/'assets/Learning_Mobile_Video.png'))
 mobile.locator('#learning-close').tap();assert mobile.locator('#reference-dialog').is_visible()
 results['touch_layout_and_parent_return']=True
 mobile.close()
 # Cross-check original data and method code hashes are unchanged (embedded vs files).
 emb=json.loads(soup.select_one('#explorer-data').text)
 assert emb==D
 for mid in [m['id'] for m in D['methods']]:
  old=next(m for m in D['methods'] if m['id']==mid)
  new=next(m for m in emb['methods'] if m['id']==mid)
  assert old.get('code')==new.get('code')
 assert json.loads(soup.select_one('#reference-data').text)==T
 assert not errors,errors
 results['console_errors']=errors
 results['scope']='Chromium injected-HTML desktop and emulated touch tests. File-origin navigation was blocked by the environment, so file-origin behavior was not independently checked. Remote player requests deliberately blocked; playback not confirmed. Safari not tested. These are UI and data checks, not scheduler performance tests.'
 browser.close()
(R/'tests/Learning_Interface_Checks.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
