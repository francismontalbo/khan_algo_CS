"""Validate the additive glossary against the preserved comparison reader."""
from pathlib import Path
import json, shutil, hashlib
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]
HTML=(R/'Workflow_Visual_Comparison.html').read_text()
D=json.loads((R/'data/Terminology.json').read_text())
results={};errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1050})
    page.set_default_timeout(5000)
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(HTML,wait_until='domcontentloaded')
    page.wait_for_function('window.workflowReference && document.querySelector("#compare-table a[data-term-id=xla]")')
    initial=page.evaluate('workflowExplorer.getState()')
    before=page.evaluate('({x:scrollX,y:scrollY,inner:document.getElementById("compare-scroll").scrollLeft})')
    xla=page.locator('#compare-table thead a[data-term-id="xla"]').first
    xla.hover();page.wait_for_function('document.getElementById("term-tooltip").matches(":popover-open")')
    assert 'Accelerated Linear Algebra' in page.locator('#term-tooltip').inner_text()
    assert page.locator('#term-tip-open').is_visible()
    page.screenshot(path=str(R/'assets/Reference_Tooltip.png'))
    page.locator('#term-tip-open').click()
    assert page.locator('#reference-dialog').is_visible()
    assert page.locator('#term-heading').inner_text()=='XLA'
    assert page.locator('.term-sources a').count()>=2
    page.screenshot(path=str(R/'assets/XLA_Explanation.png'))
    page.locator('[data-ref-related="hlo"]').click()
    assert page.locator('#term-heading').inner_text()=='HLO'
    page.locator('[data-reference-back]').click()
    assert page.locator('#term-heading').inner_text()=='XLA'
    page.locator('#reference-close').click()
    page.wait_for_timeout(100)
    after=page.evaluate('({x:scrollX,y:scrollY,inner:document.getElementById("compare-scroll").scrollLeft})')
    assert before==after,(before,after)
    assert initial==page.evaluate('workflowExplorer.getState()')
    results['tooltip_explainer_related_terms_return_and_selection_preservation']=True
    print('pass: tooltips and return',flush=True)
    # Search prioritizes exact short form and exact full form.
    page.locator('.quicknav [data-open-reference]').click()
    page.locator('#reference-search').fill('XLA')
    assert page.locator('#reference-results [data-ref-entry]').first.get_attribute('data-ref-entry')=='xla'
    page.locator('#reference-search').fill('Accelerated Linear Algebra')
    assert page.locator('#reference-results [data-ref-entry]').first.get_attribute('data-ref-entry')=='xla'
    page.locator('#reference-search').fill('C_f')
    assert page.locator('#reference-results [data-ref-entry]').first.get_attribute('data-ref-entry')=='c-f'
    page.locator('#reference-clear').click()
    for cat in ['Abbreviations','Symbols','Concepts','Code']:
        page.locator(f'[data-ref-category="{cat}"]').click()
        assert page.locator('.reference-table tbody tr').count()==sum(e['category']==cat for e in D['entries'])
        if cat=='Abbreviations':page.screenshot(path=str(R/'assets/Abbreviations_Table.png'))
        if cat=='Symbols':page.screenshot(path=str(R/'assets/Nomenclature_Table.png'))
    results['search_exact_matches_and_complete_tables']=True
    # Every definition and every related term can be opened.
    for entry in D['entries']:
        page.evaluate('(id)=>workflowReference.openTerm(id)',entry['id'])
        assert page.locator('#term-heading').inner_text()==entry['term']
        assert page.locator('.term-description').inner_text().strip()
    results['definition_records_checked']=len(D['entries'])
    page.locator('#reference-close').click()
    print('pass: tables and all definitions',flush=True)
    # Refreshes after different comparisons; help does not alter code text.
    page.locator('#comparison-preset').select_option('counters')
    page.locator('#compare-mode [data-mode="all"]').click()
    page.wait_for_timeout(250)
    assert page.locator('#compare-table a[data-term-id="remaining-xor"]').count()>0
    assert page.locator('#compare-table .math-reference').count()>0
    page.locator('#compare-table .math-reference').first.click()
    assert page.locator('[data-ref-category="Symbols"]').get_attribute('aria-pressed')=='true'
    page.locator('#reference-close').click()
    data=json.loads(BeautifulSoup(HTML,'html.parser').select_one('#explorer-data').text)
    p1=next(m for m in data['methods'] if m['id']=='P1')
    texts=page.locator('#compare-table pre code').all_text_contents()
    assert p1['code'] in texts
    # Case-sensitive matching and identifier boundaries must not corrupt code.
    assert page.locator('#compare-table .term-link .term-link').count()==0
    page.locator('#compare-table a[data-term-id="remaining-xor"]').first.click()
    assert 'unique IDs' in page.locator('#reference-detail').inner_text()
    page.locator('#reference-close').click()
    results['dynamic_render_code_text_and_symbol_help']=True
    # Parent source dialog stays open while and after reading a definition.
    page.evaluate('workflowExplorer.showSource("E20")')
    page.wait_for_timeout(200)
    source_xla=page.locator('#source-peek a[data-term-id="xla"]').first
    source_xla.click()
    assert page.locator('#reference-dialog').is_visible()
    page.keyboard.press('Escape')
    assert not page.locator('#reference-dialog').is_visible()
    assert page.locator('#source-peek').is_visible()
    page.keyboard.press('Escape')
    assert not page.locator('#source-peek').is_visible()
    results['nested_source_help_and_keyboard_escape']=True
    # Existing method buttons keep their action; their terms do not create nested links.
    page.locator('#tree-view').select_option('all')
    page.wait_for_timeout(200)
    assert page.locator('button a.term-link, a a.term-link').count()==0
    node=page.locator('[data-tree-node="E20"]')
    node.click()
    assert page.evaluate('workflowExplorer.getState().active')=='E20'
    assert not page.locator('#reference-dialog').is_visible()
    results['tree_and_existing_links_keep_their_actions']=True
    print('pass: code and source contexts',flush=True)
    # Both export paths retain the embedded definitions and need no remote scripts.
    page.locator('#comparison-preset').select_option('versions')
    page.locator('#compare-mode [data-mode="code"]').click()
    with page.expect_download() as d:page.locator('#export-comparison').click()
    out=R/'tests/Reference_Export_Test.html';d.value.save_as(str(out))
    exp=browser.new_page(viewport={'width':1360,'height':950})
    exp.on('pageerror',lambda e:errors.append(str(e)))
    print('loading exported comparison',flush=True)
    exp.set_content(out.read_text(),wait_until='domcontentloaded')
    print('loaded exported comparison',flush=True)
    exp.wait_for_function('window.workflowReference')
    print('opening export definition',flush=True)
    exp.locator('a[data-term-id="xla"]').first.click()
    print('opened export definition',flush=True)
    assert exp.locator('#term-heading').inner_text()=='XLA'
    exp.close()
    print('saving reference tables',flush=True)
    page.evaluate('workflowReference.open()')
    with page.expect_download() as d:page.locator('#reference-save').click()
    standalone=R/'Workflow_Terms_and_Nomenclature.html';d.value.save_as(str(standalone))
    ref=browser.new_page()
    ref.on('pageerror',lambda e:errors.append(str(e)))
    ref.set_content(standalone.read_text(),wait_until='domcontentloaded')
    ref.wait_for_function('window.workflowReference')
    assert ref.locator('body>section>table tbody tr').count()==len(D['entries'])
    ref.locator('a[data-term-id="xla"]').first.click()
    assert ref.locator('#term-heading').inner_text()=='XLA'
    ref.close()
    page.locator('#reference-close').click()
    results['saved_comparison_and_standalone_reference_keep_help']=True
    print('pass: exports',flush=True)
    # Direct fragment opens the corresponding explanation without changing methods.
    bookmark=browser.new_page()
    bookmark.set_content(HTML,wait_until='domcontentloaded')
    bookmark.evaluate('workflowReference.openTerm("heft")')
    assert bookmark.locator('#term-heading').inner_text()=='HEFT'
    assert bookmark.evaluate('location.hash')=='#term-heft'
    bookmark.close()
    results['stable_term_anchors']=True
    print('pass: anchors',flush=True)
    # Touch and narrow-screen rendering.
    mobile=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=1)
    mobile.on('pageerror',lambda e:errors.append(str(e)))
    mobile.set_content(HTML,wait_until='domcontentloaded')
    mobile.wait_for_function('window.workflowReference')
    mobile.locator('#compare-table thead a[data-term-id="xla"]').first.tap()
    assert mobile.locator('#term-heading').inner_text()=='XLA'
    width=mobile.evaluate('({screen:innerWidth,body:document.documentElement.scrollWidth,panel:document.getElementById("reference-dialog").getBoundingClientRect().width})')
    assert width['body']<=width['screen']+1,width
    assert width['panel']<=width['screen'],width
    mobile.screenshot(path=str(R/'assets/Mobile_Definition.png'))
    mobile.locator('[data-reference-back]').tap()
    mobile.locator('[data-ref-category="Symbols"]').tap()
    mobile.screenshot(path=str(R/'assets/Mobile_Nomenclature.png'))
    assert mobile.locator('#reference-scroll').evaluate('(e)=>e.scrollWidth<=e.clientWidth+1')
    mobile.locator('#reference-close').tap()
    results['touch_open_close_and_narrow_screen_fit']=True
    mobile.close()
    page.screenshot(path=str(R/'assets/Reference_Page.png'))
    results['console_errors']=errors
    assert not errors,errors
    browser.close()
results['scope']='Chromium desktop and emulated touch browser. Tested with injected standalone HTML; file-origin persistence and Safari were not independently tested.'
(R/'tests/Reference_Interface_Checks.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
