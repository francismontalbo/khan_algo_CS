"""Verify that a saved comparison retains the new algorithm help."""
from pathlib import Path
import json,shutil
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];out=R/'tests/algorithm_lessons'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 q=b.new_page(accept_downloads=True,viewport={'width':1400,'height':1000});errs=[];q.on('pageerror',lambda e:errs.append(str(e)))
 q.set_content((R/'Workflow_Visual_Comparison.html').read_text(),wait_until='domcontentloaded')
 with q.expect_download() as d:q.locator('#export-comparison').click()
 d.value.save_as(out/'Saved_Comparison.html')
 q.close()
 q=b.new_page(viewport={'width':1400,'height':1000});q.on('pageerror',lambda e:errs.append(str(e)))
 q.set_content((out/'Saved_Comparison.html').read_text(),wait_until='domcontentloaded')
 q.wait_for_function('!!window.workflowLearning?.showLesson')
 q.evaluate('workflowLearning.showLesson("counting")')
 assert q.locator('#algorithm-lesson-heading').inner_text()=='Reference counts and memory-aware list scheduling'
 assert q.locator('.algorithm-code pre').inner_text().find('def consumer_events')>=0
 assert not errs,errs
 b.close()
(out/'Saved_Comparison_Check.json').write_text(json.dumps({'date':'2026-10-15','saved_comparison_retains_lessons':True,'javascript_errors':errs},indent=2))
print('Saved comparison retains algorithm lessons')
