"""Exercise the standalone visual comparison without contacting external sites."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup
import json,shutil,hashlib
R=Path(__file__).resolve().parents[1]
HTML=(R/'Workflow_Visual_Comparison.html').read_text()
results={}; errors=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1100},device_scale_factor=1)
 page.set_default_timeout(6000)
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(HTML,wait_until='domcontentloaded')
 assert page.evaluate('workflowExplorer.getState().selected')==['E30','E29',None]
 assert page.locator('#compare-table thead th').count()==3
 results['default_two_columns']=True
 results['source_records']=page.locator('.source-record').count()
 results['process_rows']=page.locator('#compare-table .process-row').count()
 assert results['process_rows']==5
 assert page.locator('.state-picture').count()==2
 # Token-level differences in the matched, pinned XLA excerpts.
 page.locator('#compare-mode [data-mode="code"]').click()
 assert page.locator('#compare-table .code-changed').count()==2
 assert page.locator('#compare-table .code-unchanged').count()==6
 assert page.locator('#compare-table mark').count()>0
 page.locator('#identical-rows').check()
 assert page.locator('#compare-table .code-step').count()==2
 assert page.locator('#compare-table .code-unchanged').count()==0
 results['aligned_code_diff_and_filter']=True
 # Each preset and display mode, including methods without supplied code.
 presets=['versions','static','counters','reductions','closest','dynamic','memory']
 for preset in presets:
  page.locator('#comparison-preset').select_option(preset)
  for mode in ['summary','code','all']:
   page.locator(f'#compare-mode [data-mode="{mode}"]').click()
   n=page.evaluate('workflowExplorer.getState().selected.filter(Boolean).length')
   assert page.locator('#compare-table thead th').count()==n+1
   assert page.locator('#compare-table tbody tr').count()>0
 results['all_presets_and_modes']=21
 # Unknown state stays unaudited instead of being called a difference.
 page.locator('#comparison-preset').select_option('memory')
 page.locator('#compare-mode [data-mode="summary"]').click()
 assert 'Not audited' in page.locator('#compare-table').inner_text()
 results['unknowns_not_misrepresented_as_differences']=True
 # Search, add a third method, swap an existing method, and remove it.
 page.locator('#comparison-preset').select_option('versions')
 page.locator('#add-column').click()
 page.locator('#picker-search').fill('2022')
 page.locator('[data-pick="E20"]').click()
 assert page.evaluate('workflowExplorer.getState().selected')==['E30','E29','E20']
 assert page.locator('#add-column').is_hidden()
 page.locator('#compare-table [data-change="0"]').click()
 page.locator('#picker-search').fill('indexed')
 page.locator('[data-pick="E29"]').click()
 assert page.evaluate('workflowExplorer.getState().selected')==['E29','E30','E20']
 page.locator('#compare-table [data-remove="2"]').click()
 assert page.locator('#compare-table thead th').count()==3
 results['picker_add_swap_remove']=True
 # Source peek is a modal without a page jump. All sources have original links.
 before=page.evaluate('scrollY')
 page.locator('#compare-table [data-peek="E29"]').first.click()
 assert page.locator('#source-peek').is_visible()
 assert page.locator('#source-peek a[href^="https://"]').count()>0
 assert page.evaluate('scrollY')==before
 page.get_by_role('button',name='Back to comparison',exact=True).click()
 assert not page.locator('#source-peek').is_visible()
 results['source_preview_keeps_context']=True
 # Related method can be placed beside the current reference.
 page.locator('#related-cards [data-compare-neighbour="E08"]').click()
 assert page.evaluate('workflowExplorer.getState().selected')==['E29','E08',None]
 assert 'Different problem contracts' in page.locator('#compare-model-warning').inner_text()
 results['related_source_comparison_and_scope_warning']=True
 # Draft escaping and old format export/import.
 page.locator('#compare-table [data-change="1"]').click()
 page.locator('#picker-own').click()
 page.locator('#own-name').fill('Test draft')
 page.locator('#own-mechanism').fill('<script>window.untrusted = true</script>')
 page.locator('#own-code').fill('print("example")')
 page.locator('#save-own').click()
 assert '<script>window.untrusted = true</script>' in page.locator('#compare-table').inner_text()
 assert page.evaluate('window.untrusted === undefined')
 with page.expect_download() as n:
  page.locator('#export-workspace').click()
 n.value.save_as(str(R/'tests/Notes_Test.json'))
 page.locator('#comparison-preset').select_option('versions')
 page.locator('#workspace-file').set_input_files(str(R/'tests/Notes_Test.json'))
 page.wait_for_function('workflowExplorer.getState().selected.includes("OWN")')
 assert page.evaluate('workflowExplorer.getState().own.name')=='Test draft'
 assert page.evaluate('workflowExplorer.getState().selected.includes("OWN")')
 results['notes_export_import_and_escaping']=True
 # Export the code view and load it as its own offline page.
 page.locator('#comparison-preset').select_option('versions')
 page.locator('#compare-mode [data-mode="code"]').click()
 with page.expect_download() as d:
  page.locator('#export-comparison').click()
 d.value.save_as(str(R/'tests/Export_Test.html'))
 export=browser.new_page(viewport={'width':1440,'height':1000})
 export.set_content((R/'tests/Export_Test.html').read_text(),wait_until='domcontentloaded')
 assert export.locator('#compare-table .code-changed').count()==2
 assert export.locator('a[href^="https://"]').count()>3
 assert export.locator('.column-actions').count()==0
 results['standalone_export_with_original_sources']=True
 export.close()
 # Every method remains selectable in the source catalog; all tree entries retained.
 data=json.loads(BeautifulSoup(HTML,'html.parser').select_one('#explorer-data').string)
 real=[m for m in data['methods'] if not m.get('branch')]
 for m in real:
  page.evaluate('(id)=>workflowExplorer.chooseMethod(0,id)',m['id'])
  assert m['name'] in page.locator('#compare-table thead').inner_text()
 results['selectable_records_checked']=len(real)
 page.locator('#tree-view').select_option('all')
 assert page.locator('[data-tree-node]').count()==len(data['layouts']['all']['nodes'])
 results['tree_nodes_checked']=page.locator('[data-tree-node]').count()
 # A clean desktop snapshot for delivery.
 page.set_content(HTML,wait_until='domcontentloaded')
 page.screenshot(path=str(R/'assets/01_visual_comparison.png'))
 page.locator('#compare-mode [data-mode="code"]').click()
 page.locator('#compare').scroll_into_view_if_needed()
 page.screenshot(path=str(R/'assets/02_code_changes.png'))
 page.locator('#comparison-neighbours').scroll_into_view_if_needed()
 page.screenshot(path=str(R/'assets/03_related_methods.png'))
 page.locator('#related-cards [data-peek]').first.click()
 page.screenshot(path=str(R/'assets/04_source_preview.png'))
 page.keyboard.press('Escape')
 page.locator('#comparison-preset').select_option('counters')
 page.locator('#compare-mode [data-mode="summary"]').click()
 page.locator('#compare').scroll_into_view_if_needed()
 page.screenshot(path=str(R/'assets/05_three_methods.png'))
 # Narrow-screen containment and interaction, not just an image crop.
 mobile=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 mobile.on('pageerror',lambda e:errors.append(str(e)))
 mobile.set_content(HTML,wait_until='domcontentloaded')
 assert mobile.evaluate('document.documentElement.scrollWidth <= innerWidth')
 assert mobile.locator('#compare-scroll').evaluate('(e)=>e.scrollWidth > e.clientWidth')
 mobile.screenshot(path=str(R/'assets/06_mobile_start.png'))
 mobile.locator('#compare-table').scroll_into_view_if_needed()
 mobile.locator('#compare-scroll').evaluate('(e)=>e.scrollLeft=310')
 mobile.screenshot(path=str(R/'assets/07_mobile_next_column.png'))
 mobile.locator('#compare-table [data-change="1"]').click()
 mobile.locator('#picker-search').fill('Pearce')
 assert mobile.locator('[data-pick="D4"]').is_visible()
 mobile.keyboard.press('Escape')
 results['mobile_horizontal_comparison_no_page_overflow']=True
 results['mobile_picker']=True
 # Pinning behavior inside the full-spec region.
 page.locator('#comparison-preset').select_option('versions')
 page.locator('#compare-mode [data-mode="all"]').click()
 page.locator('#compare-scroll').evaluate('(e)=>e.scrollTop=420')
 pos=page.locator('#compare-table thead th:nth-child(2)').bounding_box()
 region=page.locator('#compare-scroll').bounding_box()
 assert abs(pos['y']-region['y'])<6
 results['spec_headers_stay_visible']=True
 results['console_errors']=errors
 assert not errors
 results['browser']='Chromium; DOM-injected standalone document. File-origin navigation is blocked by the test environment.'
 results['persistence']='Portable JSON export/import tested. File-origin localStorage persistence was not independently tested.'
 browser.close()
(R/'tests/Interface_Checks.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
