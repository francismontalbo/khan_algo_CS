from pathlib import Path
import json, time, hashlib
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'tests/final';SH=ROOT/'assets/final';OUT.mkdir(exist_ok=True);SH.mkdir(exist_ok=True)
results=[];errors=[];limitations=[]
def ck(name,ok,detail=''):
 results.append({'check':name,'passed':bool(ok),'detail':detail})
 if len(results)%50==0 or len(results)>440:print('Checked',len(results),name,flush=True)
 if not ok:print('FAIL:',name,detail,flush=True)
def close_all(page):
 page.evaluate("document.querySelectorAll('dialog[open]').forEach(d=>d.close())")
def load(page,name='Workflow_Research_Guide.html'):
 page.set_content((ROOT/name).read_text(),wait_until='domcontentloaded');page.wait_for_timeout(350)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 p=b.new_page(viewport={'width':1440,'height':1000});p.on('pageerror',lambda e:errors.append(str(e)));p.set_default_timeout(7000)
 try:
  p.goto((ROOT/'Workflow_Research_Guide.html').as_uri(),wait_until='domcontentloaded',timeout=8000);p.wait_for_timeout(350)
  ck('Main page opens directly from a local file',p.evaluate('!!window.workflowFinalEdition'))
  file_load=True
 except Exception as e:
  limitations.append('Browser policy blocked file-origin navigation; HTML contents were loaded locally for interaction checks.');file_load=False;load(p)
 ck('All modules available',p.evaluate('[workflowExplorer,workflowLearning,workflowReference,workflowSimulation,workflowApplications,workflowFinalEdition].every(Boolean)'))
 ck('Beginner default is Kahn and priority choice',p.evaluate('workflowExplorer.getState().selected.slice(0,2).join(",")==="S1,S3"'))
 ck('Correct initial preset',p.locator('#comparison-preset').input_value()=='static')
 p.screenshot(path=str(SH/'01_Overview.png'))
 D=p.evaluate('JSON.parse(document.getElementById("explorer-data").textContent)')
 methods=[m for m in D['methods'] if not m.get('branch')]
 ck('Retained 58 research selections',len(methods)==58)
 ck('Latest paper title and authors corrected',next(s for s in D['sources'] if s['id']=='E34')['title'].startswith('LATTICE') and 'Minnan Pei' in next(s for s in D['sources'] if s['id']=='E34')['authors'])
 ck('Version-family caution present','Version 1 was titled DAN-Scheduler' in next(s for s in D['sources'] if s['id']=='E34')['version_note'])
 data=p.evaluate('JSON.parse(document.getElementById("download-data").textContent)')
 ck('Export record equals displayed corrected source',next(s for s in data['sources'] if s['id']=='E34')==next(s for s in D['sources'] if s['id']=='E34'))
 # Every preset, all three render paths; source previews for all selectable methods.
 for opt in p.locator('#comparison-preset option:not([disabled])').evaluate_all('(es)=>es.map(e=>e.value)'):
  p.locator('#comparison-preset').select_option(opt)
  for view in ['summary','code','all']:
   p.evaluate('(v)=>workflowExplorer.setView(v)',view)
   ck(f'Preset {opt}: {view}',p.locator('#compare-table').inner_text().strip()!='')
 for m in methods:
  p.evaluate('(id)=>workflowExplorer.showSource(id)',m['id'])
  ck('Source view '+m['id'],p.locator('#source-peek').is_visible() if p.locator('#source-peek').count() else p.locator('dialog[open]').count()>0)
  close_all(p)
 # All tree families render with a selected node.
 for v in p.evaluate('workflowExplorer.views'):
  p.locator('#tree-view').select_option(v)
  ck('Tree view '+v,p.locator('[data-tree-node]').count()>0)
 # Every definition and learning resource goes through the actual UI path.
 for term in p.evaluate('workflowReference.ids'):
  p.evaluate('(id)=>workflowReference.openTerm(id)',term)
  ck('Term '+term,p.locator('#reference-dialog').is_visible());p.evaluate('workflowReference.close()')
 ck('Current glossary count',len(p.evaluate('workflowReference.ids'))==249)
 for rid in p.evaluate('workflowLearning.resourceIds'):
  p.evaluate('(id)=>workflowLearning.showResource(id)',rid)
  ck('Learning detail '+rid,p.locator('#learning-detail').is_visible());p.evaluate('workflowLearning.close()')
 for lid in p.evaluate('workflowLearning.lessonIds'):
  p.evaluate('(id)=>workflowLearning.showLesson(id)',lid)
  ck('Algorithm lesson '+lid,p.locator('#learning-dialog').is_visible());p.evaluate('workflowLearning.close()')
 # Run every algorithm, including new application-shaped input routes.
 appdata=p.evaluate('workflowApplications.data')
 for prof in appdata['profiles']:
  p.evaluate('(id)=>workflowApplications.open(id)',prof['id']);ck('Application '+prof['id'],p.locator('#app-main .app-source').count()==len(prof['refs']))
  p.locator('#app-main [data-app-run]').click();p.locator('#sim-last').click()
  ck('Application run '+prof['id'],p.evaluate('(id)=>workflowSimulation.getState().id===id',prof['id']) and not p.locator('#sim-error').is_visible());p.locator('#sim-close').click()
 # Focused Kahn example and exact executed code.
 p.evaluate("workflowSimulation.open('fifo')");p.locator('#sim-next').click();p.locator('#sim-next').click()
 p.screenshot(path=str(SH/'03_Simulation.png'))
 ck('Kahn decrement highlights the changed indegree','d[v]--' in p.locator('#sim-current-code-0').inner_text())
 # Help overlay must not close the running simulation underneath it.
 p.evaluate("workflowReference.openTerm('dag')")
 p.keyboard.press('Escape');p.wait_for_timeout(80)
 ck('Escape closes top definition only',not p.locator('#reference-dialog').is_visible() and p.locator('#sim-dialog').is_visible())
 p.locator('#sim-close').click();p.wait_for_timeout(100)
 ck('Navigation clears the closed simulator',p.locator('[data-ui-nav="simulations"]').get_attribute('aria-current') is None)
 p.evaluate("workflowApplications.open('fifo')");p.screenshot(path=str(SH/'04_Application.png'));p.locator('#app-close').click()
 p.locator('#comparison-preset').select_option('versions');p.evaluate("workflowExplorer.setView('code')")
 p.locator('#compare').scroll_into_view_if_needed();p.screenshot(path=str(SH/'02_Code_Comparison.png'))
 # Both literal and generated citations remain resolvable.
 broken=p.evaluate("[...document.querySelectorAll('a[href^=\"#\"]')].map(a=>a.getAttribute('href')).filter(h=>h.length>1&&!document.getElementById(decodeURIComponent(h.slice(1)))&&!(h.startsWith('#term-')&&workflowReference.ids.includes(decodeURIComponent(h.slice(6)))))")
 ck('Literal internal links resolve',len(broken)==0,str(sorted(set(broken))))
 dup=p.evaluate("(()=>{const seen=new Set(),dup=[];document.querySelectorAll('[id]').forEach(n=>{if(seen.has(n.id))dup.push(n.id);seen.add(n.id)});return dup})()")
 ck('No duplicate HTML identifiers',not dup,str(dup))
 # Save standalone comparison, reload without the original folder.
 with p.expect_download() as dl:p.locator('#export-comparison').click()
 export=OUT/'Saved_Comparison.html';dl.value.save_as(export)
 ep=b.new_page();ep.on('pageerror',lambda e:errors.append('export: '+str(e)))
 ep.set_content(export.read_text(),wait_until='domcontentloaded');ep.wait_for_timeout(250)
 ck('Saved comparison retains complete modules',ep.evaluate('!!window.workflowReference&&!!window.workflowLearning&&!!window.workflowSimulation&&!!window.workflowApplications&&!!window.workflowFinalEdition'))
 ep.evaluate("workflowSimulation.open('fifo')");ep.locator('#sim-last').click();ck('Saved simulation runs offline',not ep.locator('#sim-error').is_visible());ep.close()
 # Notes export and import.
 p.locator('#ui-more summary').click()
 with p.expect_download() as dl:p.locator('[data-ui-forward="export-workspace"]').click()
 notes=OUT/'Roundtrip_Notes.json';dl.value.save_as(notes)
 st=p.evaluate('workflowExplorer.getState()');p.locator('#comparison-preset').select_option('static')
 p.locator('#workspace-file').set_input_files(notes);p.wait_for_timeout(100)
 ck('Comparison notes restore selections',p.evaluate('workflowExplorer.getState().selected')==st['selected'])
 # Every standalone direct entry opens without a missing resource.
 entries=['Algorithm_Lessons.html','Algorithm_Simulations.html','Algorithm_Applications.html','Workflow_Learning_Resources.html','Workflow_Terms_and_Nomenclature.html']
 for fn in entries:
  np=b.new_page();np.on('pageerror',lambda e,fn=fn:errors.append(fn+': '+str(e)));load(np,fn)
  ck('Standalone heading '+fn,np.locator('h1').first.is_visible())
  if fn=='Algorithm_Lessons.html':np.locator('[data-open-algorithms]').first.click();ck('Standalone lessons open',np.locator('#learning-dialog').is_visible())
  elif fn=='Workflow_Learning_Resources.html':np.locator('[data-open-learning]').first.click();ck('Standalone tutorials open',np.locator('#learning-dialog').is_visible())
  elif fn=='Workflow_Terms_and_Nomenclature.html':np.locator('[data-term-id="xla"]').first.click();ck('Standalone definitions open',np.locator('#reference-dialog').is_visible())
  np.close()
 # Narrow viewport, meaningful modal and navigation states.
 for w in [320,390,768]:
  mp=b.new_page(viewport={'width':w,'height':844},is_mobile=w<768,has_touch=True);mp.on('pageerror',lambda e:errors.append('mobile: '+str(e)));load(mp)
  ck(f'Width {w}: no page overflow',mp.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
  if w==390:mp.screenshot(path=str(SH/'05_Mobile_Start.png'))
  mp.locator('#ui-more summary').click();ck(f'Width {w}: menu is visible',mp.locator('#ui-more').get_attribute('open') is not None)
  mp.keyboard.press('Escape')
  mp.evaluate("workflowSimulation.open('fifo')");mp.locator('#sim-next').click()
  ck(f'Width {w}: simulator controls',mp.locator('#sim-next').is_visible() and mp.locator('#sim-close').is_visible())
  if w==390:mp.screenshot(path=str(SH/'06_Mobile_Simulation.png'))
  mp.locator('#sim-close').click();mp.evaluate("workflowReference.openTerm('lattice')")
  ck(f'Width {w}: updated term view',mp.locator('#reference-dialog').is_visible());mp.close()
 # Browser print CSS renders the comparison instead of the buttons.
 p.emulate_media(media='print');ck('Print view hides fixed navigation',not p.locator('#ui-header').is_visible());p.emulate_media(media='screen')
 b.close()
ck('No JavaScript runtime errors',not errors,str(errors))
report={'checked_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'checks':len(results),'passed':sum(x['passed'] for x in results),'errors':errors,'details':results,'local_file_navigation':file_load,'limitations':limitations,'scope':'Chromium local desktop and emulated 320, 390, 768-pixel layouts; sampled interactions and all records through shared paths. Not every comparison pair, Firefox, Safari, physical devices or external video playback.'}
(OUT/'UI_Results.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['details']},indent=2));assert report['passed']==report['checks']
