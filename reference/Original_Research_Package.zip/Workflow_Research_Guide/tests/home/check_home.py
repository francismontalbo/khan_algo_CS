from pathlib import Path
from urllib.parse import urlparse, unquote
import json, zipfile
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'tests/home'
results=[];errors=[]
def check(name, ok, detail=''):
 results.append({'check':name,'passed':bool(ok),'detail':detail})
 if not ok or len(results)<65:print(('PASS' if ok else 'FAIL'),name,str(detail)[:200],flush=True)

with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 p=None
 def load(href='index.html',width=1440,height=1040):
  global p
  if p:p.close()
  p=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
  p.on('pageerror',lambda e:errors.append(str(e)))
  p.set_default_timeout(8000)
  u=urlparse(href);file=ROOT/unquote(u.path or 'index.html')
  html=file.read_text()
  # Browser policy blocks file:// and local servers. Inject only the test URL's query
  # into an in-memory copy of the routing adapter; shipped code is not changed.
  if u.query:
   html=html.replace('new URLSearchParams(window.location.search)','new URLSearchParams('+json.dumps('?'+u.query)+')')
  p.set_content(html,wait_until='domcontentloaded');p.wait_for_timeout(450)
  # Prevent attempted network navigation when testing local link selection.
  p.evaluate('''() => { window.__clickedHref=null; document.addEventListener('click', e=> {const a=e.target.closest('a');if(a && a.getAttribute('href') && !a.getAttribute('href').startsWith('#')) {e.preventDefault();window.__clickedHref=a.getAttribute('href');}},true); }''')
  if u.fragment:
   p.evaluate('(id)=>document.getElementById(id)?.scrollIntoView({block:"start",behavior:"instant"})',u.fragment)
  return p
 def follow(locator,width=1440,height=1040):
  locator.click();href=p.evaluate('window.__clickedHref')
  if not href:raise RuntimeError('No local href received')
  load(href,width,height);return href
 load()
 p.screenshot(path=str(ROOT/'assets/home/Home_Desktop.png'),full_page=True)
 check('Home renders from the self-contained file',p.title().startswith('Home'))
 check('Single primary heading',p.locator('h1').count()==1)
 check('Desktop has no page overflow',p.evaluate('document.documentElement.scrollWidth<=innerWidth'))
 check('All home links have visible text or accessible names',p.locator('a').evaluate_all('(els)=>els.every(el=>(el.getAttribute("aria-label")||el.textContent).trim())'))
 check('Home has no remote scripts, frames, or autoplay',p.locator('iframe,video,script[src]').count()==0)
 links=p.locator('a').evaluate_all('(es)=>es.map(e=>({text:e.getAttribute("aria-label")||e.textContent.trim(),href:e.getAttribute("href")}))')
 for l in links:
  u=urlparse(l['href'])
  if u.path:check('Destination exists: '+l['text'],(ROOT/unquote(u.path)).is_file())
 follow(p.get_by_role('link',name='Start with Kahn',exact=False))
 check('Start with Kahn opens the correct lesson',p.locator('#algorithm-lesson-heading').inner_text()=='Kahn’s algorithm')
 check('All original modules remain available',p.evaluate('[workflowExplorer,workflowLearning,workflowSimulation,workflowReference,workflowApplications].every(Boolean)'))
 p.screenshot(path=str(OUT/'Kahn_Destination.png'))
 p.locator('#learning-close').click()
 h=follow(p.locator('.ux-brand'));check('Guide brand links back home',h=='index.html')
 for name,q,selector,expected in [
 ('algorithms','?open=algorithms','#algorithm-index-heading','Learn the algorithms'),
 ('simulation','?open=simulation&id=fifo','#sim-dialog[open] #sim-title','Algorithm simulations'),
 ('applications','?open=applications&id=fifo',None,None),
 ('terms','?open=terms','#reference-dialog[open] #reference-title','Terms'),
 ('videos','?open=videos','#learning-dialog[open] #learning-title','Videos')]:
  load('Workflow_Research_Guide.html'+q)
  if name=='applications':check('Route opens applications',p.evaluate('workflowApplications.getState().open'))
  else:check('Route opens '+name,p.locator(selector).first.is_visible() and expected in p.locator(selector).first.inner_text())
  if name=='simulation':
   before=p.evaluate('workflowSimulation.getState().index');p.locator('#sim-next').click()
   check('Simulation can advance after entry',p.evaluate('workflowSimulation.getState().index')==before+1)
 for anchor in ['compare','questions','lineage-tree','references','idea','test']:
  load('Workflow_Research_Guide.html#'+anchor)
  box=p.locator('#'+anchor).bounding_box()
  check('Anchor target visible: '+anchor,box is not None and -15<=box['y']<=210,str(box['y'] if box else None))
 load('Workflow_Research_Guide.html')
 check('Existing initial comparison preserved',p.evaluate('workflowExplorer.getState().selected.slice(0,2).join(",")==="S1,S3"'))
 p.locator('#ui-more summary').click();h=follow(p.locator('#ui-more a[href="index.html"]'))
 check('More menu includes working Home target',h=='index.html')
 load();p.keyboard.press('Tab')
 check('Keyboard starts with skip link',p.evaluate('document.activeElement.classList.contains("skip-link")'))
 for width,height,name in [(1024,900,'Tablet'),(768,1024,'Compact'),(390,844,'Mobile'),(320,750,'Narrow')]:
  load(width=width,height=height)
  check(name+' layout has no page overflow',p.evaluate('document.documentElement.scrollWidth<=innerWidth'))
  check(name+' primary action has 44px minimum height',p.locator('.button.primary').bounding_box()['height']>=44)
  p.screenshot(path=str(ROOT/f'assets/home/Home_{name}.png'),full_page=True)
 load(width=390,height=844)
 follow(p.get_by_role('link',name='Start with Kahn',exact=False),390,844)
 check('Mobile primary action opens lesson',p.locator('#algorithm-lesson-heading').is_visible())
 p.locator('#learning-close').click();h=follow(p.locator('.ux-brand'),390,844)
 check('Mobile return target is home',h=='index.html')
 for f in ['Algorithm_Lessons.html','Algorithm_Simulations.html','Algorithm_Applications.html','Workflow_Learning_Resources.html','Workflow_Terms_and_Nomenclature.html','Verification.html','Audit_Report.html']:
  load(f);p.evaluate('document.querySelectorAll("dialog[open]").forEach(d=>d.close())')
  h=p.locator('a.home-return')
  check('Home link in '+f,h.count()==1 and h.get_attribute('href')=='index.html')
  dest=follow(h)
  check('Home return from '+f,dest=='index.html')
 check('No JavaScript page errors',not errors,str(errors))
 browser.close()

previous=json.loads((OUT/'Previous_File_Hashes.json').read_text())
current=BeautifulSoup((ROOT/'Workflow_Research_Guide.html').read_text(),'html.parser')
import hashlib
for sid,digest in previous['modules'].items():
 el=current.find('script',id=sid)
 check('Preserved embedded module '+sid,el is not None and hashlib.sha256((el.string or '').encode()).hexdigest()==digest)
for filename,digest in previous['files'].items():
 rel=Path(filename)
 check('Retained file '+filename,(ROOT/rel).is_file())
 if rel.parts[0] in ('data','code','simulations','applications'):
  check('Unchanged source or algorithm '+filename,hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest)
check('Compatibility guide remains identical',(ROOT/'Workflow_Visual_Comparison.html').read_bytes()==(ROOT/'Workflow_Research_Guide.html').read_bytes())
report={'edition':'Home-page addition to the 15 October 2026 research edition','tests':results,'passed':sum(x['passed'] for x in results),'total':len(results),'page_errors':errors,'limits':['Chromium with local HTML loaded through set_content at desktop and emulated viewport sizes.','Browser policy blocks local-file and network navigation. Local destination files and link selections were checked, then loaded in memory with their query parameters supplied to the entry adapter. This is not an end-to-end file:// or HTTP navigation test.','Existing source and algorithm modules were checked for byte-for-byte preservation; literature and algorithms were not re-audited in this UI revision.','External videos and papers were not opened.']}
(OUT/'Home_Checks.json').write_text(json.dumps(report,indent=2))
print('TOTAL',report['passed'],report['total'])
assert report['passed']==report['total'],'See failed checks.'
