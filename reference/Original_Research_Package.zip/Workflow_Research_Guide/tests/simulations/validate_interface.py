"""Chromium checks for the simulation UI. Rendering uses set_content because the
sandbox blocks file and loopback navigation. This is not a cross-browser audit.
"""
from pathlib import Path
from datetime import datetime, timezone
from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup
import json, hashlib, tempfile

ROOT=Path(__file__).resolve().parents[2]
DATA=json.loads((ROOT/'simulations/data.json').read_text())
HTML=(ROOT/'Workflow_Visual_Comparison.html').read_text()
REPORT={'executed_utc':datetime.now(timezone.utc).isoformat(),'checks':[], 'failures':[], 'limitations':['Chromium HTML-string rendering; file and loopback URL navigation are blocked in the sandbox.','No Safari or Firefox check; no external video playback test.']}
def record(name,ok,detail=None):
    REPORT['checks'].append({'name':name,'passed':bool(ok),'detail':detail})
    if not ok:REPORT['failures'].append(name)

before=BeautifulSoup((ROOT/'archive/Before_Simulations.html').read_text(),'html.parser')
after=BeautifulSoup(HTML,'html.parser')
for ident in ['explorer-data','visual-data','learning-data','reference-data','download-data']:
    a,b=before.find(id=ident),after.find(id=ident)
    record('Preserved '+ident,a and b and json.loads(a.string)==json.loads(b.string))
record('Embedded engine matches tested source',after.find(id='simulation-engine').string==(ROOT/'simulations/engine.js').read_text())

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1050},accept_downloads=True)
    page.set_default_timeout(5000)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(HTML,wait_until='domcontentloaded');page.wait_for_timeout(500)
    record('Main menu and primary simulation CTA',page.locator('[data-sim-open="fifo"]').count()==2)
    for entry in DATA['engines']:
        result=page.evaluate('''id=>{workflowSimulation.open(id);const s=workflowSimulation.getState();document.getElementById('sim-last').click();return {s,visible:document.getElementById('sim-dialog').open,output:document.querySelector('.sim-output').innerText,error:document.getElementById('sim-error').hidden,rows:document.querySelectorAll('.sim-code-line').length};}''',entry['id'])
        record('Render and finish '+entry['id'],result['visible'] and result['s']['frames'][0]>0 and result['error'] and result['rows']>0, result['output'])
    for ident,m in DATA['methods'].items():
        result=page.evaluate('''([engine,id])=>{workflowSimulation.open(engine,id);return {state:workflowSimulation.getState(),text:document.getElementById('sim-context').innerText,hidden:document.getElementById('sim-context').hidden};}''',[m['engine'],ident])
        record('Scope route '+ident,not result['hidden'] and result['state']['context']==ident and m['note'] in result['text'])
    page.evaluate("workflowSimulation.open('fifo')")
    page.locator('#sim-next').click();page.locator('#sim-next').click();page.locator('#sim-prev').click()
    record('Forward and backward steps',page.evaluate('workflowSimulation.getState().index')==1)
    page.locator('#sim-reset').click();page.keyboard.press('ArrowRight')
    record('Keyboard stepping',page.evaluate('workflowSimulation.getState().index')==1)
    page.locator('#sim-speed').select_option('500');page.locator('#sim-play').click();page.wait_for_timeout(600);page.locator('#sim-play').click()
    s=page.evaluate('workflowSimulation.getState()');record('Play then pause',s['index']>=2 and not s['running'])
    page.locator('#sim-last').click();record('Final output visible',page.locator('.sim-output').first.inner_text().strip()!='')
    page.locator('#sim-runs .sim-code-select').first.select_option('javascript');record('Code line highlight',page.locator('.sim-code-line.on').count()>0)
    page.locator('#sim-reset').click();page.locator('[data-sim-node="A"]').first.click();record('Graph node explanation', 'Prerequisites' in page.locator('#sim-node-note-0').inner_text())
    page.locator('#sim-edit').click();original=page.locator('#sim-input-json').input_value()
    page.locator('#sim-input-json').fill('{broken');page.locator('#sim-apply').click();record('Reject malformed JSON',not page.locator('#sim-error').is_hidden())
    page.locator('#sim-input-json').fill(json.dumps({'nodes':['X','Y'],'edges':[['X','Y']]}));page.locator('#sim-apply').click();record('Edited input applied',page.locator('#sim-example').input_value()=='custom' and page.locator('#sim-error').is_hidden())
    with page.expect_download() as di: page.locator('#sim-export').click()
    saved=json.loads(Path(di.value.path()).read_text());record('JSON run export',saved['runs'][0]['input']['nodes']==['X','Y'] and len(saved['runs'][0]['frames'])>0)
    page.locator('#sim-input-panel summary').click() if page.locator('#sim-input-panel').get_attribute('open') is None else None
    with page.expect_download() as di:page.locator('#sim-save-code').click()
    source=Path(di.value.path()).read_text();record('Runnable code export',source==(ROOT/'simulations/engine.js').read_text())
    page.locator('#sim-reset-input').click();record('Restore authored example',page.locator('#sim-example').input_value()!='custom')
    page.evaluate("workflowSimulation.open('counters')");page.locator('#sim-compare').click()
    record('Compatible comparison',len(page.evaluate('workflowSimulation.getState().runIds'))==2 and page.locator('.sim-run').count()==2)
    page.locator('#sim-last').click()
    out=page.locator('.sim-output .output-value').all_text_contents();record('Equivalent policy orders agree on example',len(set(out))==1,out)
    page.locator('#sim-close').click()
    page.evaluate("workflowLearning.showLesson('kahn')");page.wait_for_timeout(300)
    record('Lesson simulation CTA',page.locator('.sim-lesson-cta').count()==1)
    page.locator('.sim-lesson-cta').click();page.keyboard.press('Escape')
    record('Return to lesson after Escape',not page.locator('#sim-dialog').is_visible() and page.locator('#algorithm-lesson-heading').is_visible())
    page.evaluate('workflowLearning.close()')
    page.evaluate("workflowSimulation.open('fifo')");page.locator('#sim-library').click();page.locator('#sim-catalog-search').fill('Pearce')
    record('Search source and algorithm catalog',page.locator('.sim-catalog-item').count()>0)
    page.locator('#sim-close').click()
    with page.expect_download() as di:page.locator('#export-comparison').click()
    exported=Path(di.value.path()).read_text()
    record('Comparison export includes complete simulator','simulation-engine' in exported and 'simulation-data' in exported)
    export_page=browser.new_page();ex_errors=[];export_page.on('pageerror',lambda e:ex_errors.append(str(e)))
    export_page.set_content(exported,wait_until='domcontentloaded');export_page.wait_for_timeout(300)
    export_page.evaluate("workflowSimulation.open('heft')");export_page.locator('#sim-last').click()
    record('Exported comparison simulation runs',export_page.locator('#sim-dialog').is_visible() and not ex_errors,ex_errors)
    export_page.close()
    record('Desktop JavaScript errors',not errors,errors)
    page.close()
    for width,height in [(320,740),(390,844),(768,1024)]:
        page=browser.new_page(viewport={'width':width,'height':height},is_mobile=width<600,has_touch=width<600)
        page.set_content(HTML,wait_until='domcontentloaded');page.wait_for_timeout(250)
        page.evaluate("workflowSimulation.open('fifo')")
        dims=page.evaluate('''()=>({doc:document.documentElement.scrollWidth,w:innerWidth,dialog:document.getElementById('sim-dialog').getBoundingClientRect().width,body:document.getElementById('sim-body').clientHeight,controls:document.querySelector('.sim-controls').getBoundingClientRect().bottom,h:innerHeight})''')
        record('Responsive '+str(width),dims['doc']<=width+1 and dims['dialog']<=width+1 and dims['body']>160 and dims['controls']<=height+1,dims)
        page.locator('#sim-next').click();record('Touch-size stepping '+str(width),page.evaluate('workflowSimulation.getState().index')==1)
        if width==390:
            page.locator('#sim-compare').click();dims=page.evaluate('''()=>{const e=document.querySelector('.sim-runs-scroll');return {view:e.clientWidth,content:e.scrollWidth}}''');record('Mobile paired runs scroll horizontally',dims['content']>dims['view'],dims)
        page.close()
    page=browser.new_page();page.set_content((ROOT/'Algorithm_Simulations.html').read_text(),wait_until='domcontentloaded');record('Standalone simulator opens',page.locator('#sim-dialog').is_visible());page.close()
    browser.close()
REPORT['passed']=sum(c['passed'] for c in REPORT['checks'])
REPORT['total']=len(REPORT['checks'])
(ROOT/'tests/simulations/Interface_Validation.json').write_text(json.dumps(REPORT,indent=2))
print(json.dumps({'passed':REPORT['passed'],'total':REPORT['total'],'failures':REPORT['failures']},indent=2))
if REPORT['failures']:raise SystemExit(1)
